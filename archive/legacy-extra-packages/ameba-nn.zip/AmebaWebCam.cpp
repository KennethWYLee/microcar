#include "AmebaWebCam.h"
#include <WiFi.h>


WiFiServer server(80);

// 靜態成員變數定義
bool AmebaWebCam::isServerStart = false;
int AmebaWebCam::imgChannel = 0;
uint32_t AmebaWebCam::imgAddr = 0;
uint32_t AmebaWebCam::imgLen = 0;

AmebaWebCam::AmebaWebCam(uint16_t stackSize, UBaseType_t priority, 
             const char *taskName, int channel) : BaseTask(stackSize, priority, taskName) {
  imgChannel = channel;  
}

void AmebaWebCam::start() {  
  server.begin();
  isServerStart = true;
}

void AmebaWebCam::stop() {   
  server.stop(); 
  isServerStart = false;
}

void AmebaWebCam::sendChunk(WiFiClient& client, uint8_t* buf, uint32_t len) {
  uint8_t chunk_buf[64] = {0};
  uint8_t chunk_len = snprintf((char*)chunk_buf, 64, "%lX\r\n", len);
  client.write(chunk_buf, chunk_len);
  client.write(buf, len);
  client.print("\r\n");
}

void AmebaWebCam::httpRequest() {
  while(isServerStart) {
    WiFiClient client = server.available();
    if(client) {
      String currentLine = "";
      while(client.connected()) {
        if(client.available()) {
          char c = client.read();
          if(c == '\n') {
            if(currentLine.length() == 0) {
              client.println("HTTP/1.1 200 OK");
              client.print("Content-type: multipart/x-mixed-replace; boundary=");
              client.println(PART_BOUNDARY);
              client.print("Transfer-Encoding: chunked\r\n");
              client.print("\r\n");
              
              while (client.connected() && isServerStart) {  // 添加 isServerStart 檢查
                // 修正：使用正確的 Camera 函數調用                
                Camera.getImage(imgChannel, &imgAddr, &imgLen);
                uint8_t chunk_buf[64] = {0};
                // 修正：IMG_HEADER 使用方式
                uint8_t chunk_len = snprintf((char*)chunk_buf, 64, IMG_HEADER, imgLen);
                sendChunk(client, chunk_buf, chunk_len);
                sendChunk(client, (uint8_t*)imgAddr, imgLen);
                // 修正：STREAM_BOUNDARY 使用方式
                sendChunk(client, (uint8_t*)STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));
                
                delay(20);    // Increase this delay for higher resolutions to get a more consistent, but lower frame rate
              }
              break;
            } else {
              currentLine = "";
            }
          } else if (c != '\r') {
            currentLine += c;
          }
        }
      }
      client.stop();
    }
    delay(100);  // 添加小延遲避免過度消耗 CPU
  }   
}