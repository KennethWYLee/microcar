#ifndef _AMEBA_WEBCAM_H_
#define _AMEBA_WEBCAM_H_

#include <Arduino.h>
#include <WiFi.h>
#include "StreamIO.h"
#include "VideoStream.h"
#include "VideoStreamOverlay.h"

#define PART_BOUNDARY "123456789000000000000987654321"

#define IMG_HEADER "Content-Type: image/jpeg\r\nContent-Length: %lu\r\n\r\n"
#define STREAM_BOUNDARY "\r\n--123456789000000000000987654321\r\n"

class BaseTask
{
    public:
        BaseTask (uint16_t stackSize, UBaseType_t priority, const char *taskName = "")
        {
            // 修正：移除多餘的參數，xTaskCreate 只有 6 個參數
            xTaskCreate (blinkLed, taskName, stackSize, this, priority, &this->taskHandle);
        }

        virtual void main() = 0;

    protected:
        static void blinkLed (void *pvParam)
        {
            BaseTask *pBaseTask = static_cast<BaseTask*>(pvParam);
            pBaseTask->main();
        }

        TaskHandle_t taskHandle;
};

class AmebaWebCam : public BaseTask {
public:
  AmebaWebCam(uint16_t stackSize,        // class BaseTasks's arguments
             UBaseType_t priority, 
             const char *taskName,
             int channel);

  void start();
  void stop();

  void main() override
  {
    this->httpRequest();
  }

private:
  static void sendChunk(WiFiClient& client, uint8_t* buf, uint32_t len);
  static void httpRequest();

  // 修正：聲明靜態成員變數
  static bool isServerStart;
  static int imgChannel;
  static uint32_t imgAddr;
  static uint32_t imgLen;
  
  // 新增：非靜態成員變數用於構造函數參數
  int _channel;
};

#endif