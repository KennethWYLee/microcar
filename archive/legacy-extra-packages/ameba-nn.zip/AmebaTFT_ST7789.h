#ifndef _AMEBA_ST7789_H_
#define _AMEBA_ST7789_H_

#include "Print.h"
#include <cstdint>
#include "SPI.h"

#define TFT_SPI    SPI1

#define ST7789_WIDTH 320
#define ST7789_HEIGHT 240

#define ST7789_NOP         0x00
#define ST7789_SWRESET     0x01
#define ST7789_RDDID       0x04
#define ST7789_RDDST       0x09

#define ST7789_SLPIN       0x10  // sleep on
#define ST7789_SLPOUT      0x11  // sleep off
#define ST7789_PTLON       0x12  // partial on
#define ST7789_NORON       0x13  // partial off

#define ST7789_INVOFF      0x20  // invert off
#define ST7789_INVON       0x21  // invert on
#define ST7789_GAMMASET    0x26
#define ST7789_DISPOFF     0x28  // display off
#define ST7789_DISPON      0x29  // display on
#define ST7789_IDMOFF      0x38  // idle off
#define ST7789_IDMON       0x39  // idle on

#define ST7789_CASET       0x2A
#define ST7789_PASET       0x2B
#define ST7789_RAMWR       0x2C
#define ST7789_RAMRD       0x2E

#define ST7789_PTLAR       0x30  // partial start/end
#define ST7789_MADCTL      0x36
#define ST7789_PIXFMT      0x3A

#define ST7789_RDMODE      0x0A
#define ST7789_RDMADCTL    0x0B
#define ST7789_RDPIXFMT    0x0C
#define ST7789_RDIMGFMT    0x0D
#define ST7789_RDSELFDIAG  0x0F

#define ST7789_FRMCTR1     0xB1
#define ST7789_FRMCTR2     0xB2
#define ST7789_FRMCTR3     0xB3
#define ST7789_INVCTR      0xB4
#define ST7789_DFUNCTR     0xB6

#define ST7789_PWCTR1      0xC0
#define ST7789_PWCTR2      0xC1
#define ST7789_PWCTR3      0xC2
#define ST7789_PWCTR4      0xC3
#define ST7789_PWCTR5      0xC4
#define ST7789_VMCTR1      0xC5
#define ST7789_VMCTR2      0xC7

#define ST7789_RDID1       0xDA
#define ST7789_RDID2       0xDB
#define ST7789_RDID3       0xDC
#define ST7789_RDID4       0xDD

#define ST7789_GMCTRP1     0xE0
#define ST7789_GMCTRN1     0xE1

#define ST7789_MADCTL_MY   0x80
#define ST7789_MADCTL_MX   0x40
#define ST7789_MADCTL_MV   0x20
#define ST7789_MADCTL_ML   0x10
#define ST7789_MADCTL_RGB  0x00
#define ST7789_MADCTL_BGR  0x08
#define ST7789_MADCTL_MH   0x04

// Color definitions 16-bit RGB565
#define ST7789_BLACK       0x0000
#define ST7789_WHITE       0xFFFF
#define ST7789_RED         0xF800
#define ST7789_GREEN       0x07E0
#define ST7789_BLUE        0x001F
#define ST7789_CYAN        0x07FF
#define ST7789_MAGENTA     0xF81F
#define ST7789_YELLOW      0xFFE0
#define ST7789_ORANGE      0xFC00

#define ST7789_NAVY        0x000F
#define ST7789_DARKGREEN   0x03E0
#define ST7789_DARKCYAN    0x03EF
#define ST7789_MAROON      0x7800
#define ST7789_PURPLE      0x780F
#define ST7789_OLIVE       0x7BE0
#define ST7789_LIGHTGREY   0xC618
#define ST7789_DARKGREY    0x7BEF
#define ST7789_GREENYELLOW 0xAFE5
#define ST7789_PINK        0xF81F


class AmebaST7789 : public Print {
public:
    AmebaST7789(int csPin, int dcPin, int resetPin, int blPin);

    void begin(int width, int height);

    void setAddress(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);

    void writecommand(uint8_t command);
    void writedata(uint8_t data);
    void writedata(uint8_t *data, size_t datasize);

    void setRotation(uint8_t m);

    void clr();
    void fillScreen(uint16_t color);
    void fillRectangle(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    
    void drawBitmap(int16_t x, int16_t y, int16_t w, int16_t h, const unsigned short *color);
    void drawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, int16_t w, int16_t h, uint16_t color);
    void drawPixel(int16_t x, int16_t y, uint16_t color);

    void drawChar(int16_t x, int16_t y, unsigned char c, uint16_t fontcolor, uint16_t background, uint8_t fontsize);
    void drawChar(unsigned char c);
    void drawText(int16_t x, int16_t y, const String text, uint16_t fontcolor, uint8_t fontsize);

    void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
    void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1);

    void drawRectangle(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void drawRectangle(int16_t x, int16_t y, int16_t w, int16_t h);

    void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
    void drawCircle(int16_t x0, int16_t y0, int16_t r);

    virtual size_t write(uint8_t);

    int16_t getWidth();
    int16_t getHeight();

    void setCursor(int16_t x, int16_t y);
    void setForeground(uint16_t color);
    void setBackground(uint16_t color);
    void setFontSize(uint8_t size);

    static const byte BIT_12 = 0x03;
	static const byte BIT_16 = 0x05;
	static const byte BIT_18 = 0x06;
	static const byte BIT_24 = 0x07;
    void setColorMode(byte);
	void setColorMode(byte, byte);
	void setBrightness(byte);
    void setScrollLine(unsigned int);
	void setScrollArea(unsigned int, unsigned int);
    void setDisplay(bool);
    void setSleepMode(bool);
    void setInverseColor(bool);
    void setLightOn(bool);

    void clearLine(int16_t y, uint16_t bgColor = ST7789_BLACK);
    void clearLine(int16_t y, uint8_t fontSize, uint16_t bgColor = ST7789_BLACK);
    void clearLineBackground(int16_t y, uint8_t fontSize);

private:
    void reset(void);

    int _csPin;
    int _dcPin;
    int _resetPin;
    int _blPin;

    uint32_t _dcPort;
    uint32_t _dcMask;

    int16_t tft_width;
    int16_t tft_height;
    int16_t _width;
    int16_t _height;

    int16_t cursor_x;
    int16_t cursor_y;
    uint16_t foreground;
    uint16_t background;
    uint8_t fontsize;
    uint8_t rotation;

    uint16_t offsetX = 0;
    uint16_t offsetY = 0;

    unsigned int line = 0;
	unsigned int scrollY = 0;
	unsigned int scrollH = 320;	
    byte ramBits;
	byte colorBits;
};

#endif
