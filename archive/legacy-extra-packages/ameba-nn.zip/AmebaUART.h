
#ifndef _AMEBA_UART_
#define _AMEBA_UART_

#include "HardwareSerial.h"
#include "RingBuffer.h"

#define UART3_RX 14
#define UART3_TX 15

class AmebaUART: public HardwareSerial {
public:
    AmebaUART(int dwIrq, RingBuffer *pRx_buffer);
    void begin(const uint32_t dwBaudRate)
    {
        begin(dwBaudRate, SERIAL_8N1);
    }
    void begin(const uint32_t dwBaudRate, uint8_t serial_config_value);
    void end(void);
    int available(void);
    int peek(void);
    int read(void);
    void flush(void);
    size_t write(const uint8_t c);
    //        void IrqHandler(void);
    using Print::write;    // pull in write(str) and write(buf, size) from Print
    operator bool()
    {
        return true;
    }    // UART always active
    void setCallback(void (*userDefinedCallback)());
    void (*localPointerToCallback)();

protected:
    void init(const uint32_t dwBaudRate, const uint32_t config);
    RingBuffer *_rx_buffer;
    int _dwIrq;

private:
    friend bool MySerialAavailable();
    //void IrqHandler(void);
    
};

extern AmebaUART MySerial;

#endif    // _AMEBA_UART_
