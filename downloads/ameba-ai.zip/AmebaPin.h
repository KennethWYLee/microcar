#ifndef __AMEBA_PIN_H__
#define __AMEBA_PIN_H__


#define PIN_UART_TX     15
#define PIN_UART_RX     14
#define PIN_I2C_SCL     13
#define PIN_I2C_SDA     12

#define PIN_DMIC_CLK    18
#define PIN_DMIC_DATA   16

#define PIN_LED_GREEN   24
#define PIN_LED_BLUE    23

#define PIN_LCD_SCL     1
#define PIN_LCD_SDA     2
#define PIN_LCD_CS      3
#define PIN_LCD_DC      6
#define PIN_LCD_RESET   7
#define PIN_LCD_BL      8

#define PIN_D0          0
#define PIN_D4          4
#define PIN_D5          5
#define PIN_D17         17
#define PIN_D19         19
#define PIN_D20         20
#define PIN_D29         29

#define PIN_A0          11
#define PIN_A1          10
#define PIN_A2          9
#define PIN_A6          21
#define PIN_A7          22

#define PIN_SW3         5

#endif