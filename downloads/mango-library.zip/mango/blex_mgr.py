
class BlexMgr:    
    has_sdcard = False
    exec_mode = 0
    file_size = 0
    scripts = ""
    file_name = ""
    f = None