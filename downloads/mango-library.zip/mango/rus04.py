# This program for ultrasonic sensor with RGB LED
#
# Author : Chihmin Lo
# Date   : 2024/03/15

from machine import Pin
from mango import WS2812B
from mango import utils
import utime as time
 
class RUS04:
    SOUND_SPEED=340
    TRIG_PULSE_DURATION_US=10
    
    def __init__(self, sensor_pin=15, rgb_pin=10, rgb_channel=2):
        self.rgb_strip = WS2812B(pin=rgb_pin, leds=6, sm_id=rgb_channel)
        self.sensor = Pin(sensor_pin, Pin.IN)
        self.distance = 0
        
    def port(self, port_num='D'):
        if port_num == 'D':
            self.rgb_strip = WS2812B(sm_id=4, pin=10, leds=6, brightness=1)
            self.sensor = Pin(15, Pin.IN) 
        elif port_num == 'E':
            self.rgb_strip = WS2812B(sm_id=4, pin=28, leds=6, brightness=1)
            self.sensor = Pin(29, Pin.IN)
           
    def calcu_distance(self, duration, mode="CM"):
        distParam = 0.03432
        if mode == "MM": 
            distParam = 0.3432
        dist = (duration * distParam) / 2
        dist = round(dist, 0)
        return dist
            
    def detect(self):
        self.sensor.init(mode=Pin.OUT)
        self.sensor.off()
        time.sleep_us(100)
        self.sensor.on()
        time.sleep_us(5)
        self.sensor.off()
        self.sensor.init(mode=Pin.IN)
        while self.sensor.value()==0:
            pulse_start = time.ticks_us()
        while self.sensor.value()==1:
            pulse_end = time.ticks_us()
        pulse_duration = pulse_end - pulse_start    
        return pulse_duration
    
    def ping(self):        
        duration = self.detect()
        self.distance = self.calcu_distance(duration)
        return self.distance

    def rgb_all(self, color):
        self.rgb_strip.fill(color)
        self.rgb_strip.show()
        
    def rgb_close(self):        
        self.rgb_strip.close()
        
        
# example
if __name__ == '__main__':
    sensor = RUS04(sensor_pin=17, rgb_pin=16)
    sensor.rgb_all((255,0,0))
    for i in range(500):
        dist = sensor.ping()        
        print(f'distance = {dist} cm')
        time.sleep_ms(100)
        idx = round(i % 7)
        color = utils.COLORS[idx]
        sensor.rgb_all(color)
    sensor.rgb_close()
