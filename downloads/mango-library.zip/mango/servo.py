from machine import Pin, PWM
from mango import utils

class Servo:
    def __init__(self, pin=7, freq=50, min_duty=1638, max_duty=8192, min_angle=0, max_angle=180):
        self.min_duty = min_duty
        self.max_duty = max_duty
        self.min_angle = min_angle
        self.max_angle = max_angle
        self.freq = freq 
        self.pin = Pin(pin, Pin.OUT)     
        self.pwm = PWM(self.pin)
        self.pwm.freq(freq)
        self.is_action = True
        self.min_limit = min_angle
        self.max_limit = max_angle
        self.release_buzzer()

    def __del__(self):
        self.release()
        
    def release_buzzer(self):
        bz_pin = Pin(22, Pin.OUT)               

    def set_limit(self, min, max):
        self.min_limit = min
        self.max_limit = max
    
    def position(self, angle):
        if angle < self.min_limit:
            angle = self.min_limit
        if angle > self.max_limit:
            angle = self.max_limit            
        duty = utils.map_int(angle, self.min_angle, self.max_angle, self.min_duty, self.max_duty)
        self.pwm.duty_u16(duty)

    def release(self):        
        self.pwm.deinit()
        self.pin.init(Pin.OUT)
        self.is_action = False

    def reset(self):
        if self.is_action == False:
            self.pwm = PWM(self.pin)
            self.pwm.freq(self.freq)
            self.is_action = True
    
    
class CubeCarrier(Servo):
    def __init__(self, pin=6, open_pos=110, close_pos=10):
        super().__init__(pin=pin)
        self.open_pos = open_pos
        self.close_pos = close_pos
        
    def gate_open(self):
        self.position(self.open_pos)
        
    def gate_close(self):
        self.position(self.close_pos)
        

if __name__ == '__main__':
    import utime, board
    servo_grip = Servo(pin=board.S1)
    servo_arm = Servo(pin=board.S2)
    #servo.set_limit(0, 30)
    servo_grip.position(180)
    utime.sleep(2)
    servo_arm.position(140)
    utime.sleep(2)
    servo_grip.position(105)
    utime.sleep(1)
    servo_arm.position(60)
    utime.sleep(1)
    #servo.release()
    print("--- servo released ---")