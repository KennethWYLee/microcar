from machine import Pin, I2C

class SX1508def:
    RegInputDisable     = 0x00    
    RegPullUp           = 0x03
    RegPullDown         = 0x04
    RegOpenDrain        = 0x05    
    RegPolarity         = 0x06    
    RegDir              = 0x07    
    RegData             = 0x08    
    RegInterruptMask    = 0x09
    RegClock            = 0x0F
    RegMisc             = 0x10
    RegLEDDriverEnable  = 0x11
      
    RegReset   = 0x7D
    RegTest1   = 0x7E
    RegTest2   = 0x7F

    INTERNAL_CLOCK_2MHZ = 2
    ANALOG_OUTPUT = 0x3
    OUTPUT = 2
    INPUT_PULLUP = 3
    LedLinear = 0
    LedLogarithmic = 1
    SLAVE_ADDRESS = 0x21
    HIGH = 255
    LOW  = 0
    pinRESET = -1


    def __init__(self):        
        self._REG_I_ON_0    = 0x16    #  RegIOn0 ON intensity register for I/O[0] 1111 1111
        self._REG_I_ON_1    = 0x17    #  RegIOn1 ON intensity register for I/O[1] 1111 1111
        self._REG_T_ON_2    = 0x18    #  RegTOn2 ON time register for I/O[2] 0000 0000
        self._REG_I_ON_2    = 0x19    #  RegIOn2 ON intensity register for I/O[2] 1111 1111
        self._REG_OFF_2     = 0x1A    #  RegOff2 OFF time/intensity register for I/O[2] 0000 0000
        self._REG_T_ON_3    = 0x1B    #  RegTOn3 ON time register for I/O[3] 0000 0000
        self._REG_I_ON_3    = 0x1C    #  RegIOn3 ON intensity register for I/O[3] 1111 1111
        self._REG_OFF_3     = 0x1D    #  RegOff3 OFF time/intensity register for I/O[3] 0000 0000
        self._REG_T_RISE_3  = 0x1E    #  RegTRise3 Fade in register for I/O[3] 0000 0000
        self._REG_T_FALL_3  = 0x1F    #  RegTFall3 Fade out register for I/O[3] 0000 0000
        self._REG_I_ON_4    = 0x20    #  RegIOn4 ON intensity register for I/O[4] 1111 1111
        self._REG_I_ON_5    = 0x21    #  RegIOn5 ON intensity register for I/O[5] 1111 1111
        self._REG_T_ON_6    = 0x22    #  RegTOn6 ON time register for I/O[6] 0000 0000
        self._REG_I_ON_6    = 0x23    #  RegIOn6 ON intensity register for I/O[6] 1111 1111
        self._REG_OFF_6     = 0x24    #  RegOff6 OFF time/intensity register for I/O[6] 0000 0000
        self._REG_T_ON_7    = 0x25    #  RegTOn7 ON time register for I/O[7] 0000 0000
        self._REG_I_ON_7    = 0x26    #  RegIOn7 ON intensity register for I/O[7] 1111 1111
        self._REG_OFF_7     = 0x27    #  RegOff7 OFF time/intensity register for I/O[7] 0000 0000
        self._REG_T_RISE_7  = 0x28    #  RegTRise7 Fade in register for I/O[7] 0000 0000
        self._REG_T_FALL_7  = 0x29    #  RegTFall7 Fade out register for I/O[7] 0000 0000
        
        self.RegIOn = [self._REG_I_ON_0, self._REG_I_ON_1, self._REG_I_ON_2, self._REG_I_ON_3,
                        self._REG_I_ON_4, self._REG_I_ON_5, self._REG_I_ON_6, self._REG_I_ON_7]

        self.RegTOn = [self._REG_T_ON_2, self._REG_T_ON_3, self._REG_T_ON_6, self._REG_T_ON_7]

        self.RegOff = [self._REG_OFF_2, self._REG_OFF_3, self._REG_OFF_6, self._REG_OFF_7]

        self.RegTRise = [0xFF, 0xFF, self._REG_T_RISE_3, self._REG_T_RISE_7]

        self.RegTFall = [0xFF, 0xFF, self._REG_T_FALL_3, self._REG_T_FALL_7]

class SX1508:
    defs = SX1508def()
    
    def __init__(self, i2c, addr=0x3e):        
        self._i2c = i2c
        self._addr = addr
        self._buf1 = bytearray(2)
        if self._i2c.scan().count(addr) == 0:
            raise OSError('SX1508 not found at I2C addr {:#x}'.format(addr))

        tstReg = self._readWord(self.defs.RegInterruptMask); # This should return 0xFF00
        if(tstReg == 0xFF00):
            print("SX1508__init success.")

    def _write(self, addr, val):
        try:
            self._i2c.writeto_mem(self._addr, addr, int(val).to_bytes(1, "little"))
        except:
            pass

    def _ledDriverInit(self, pin, freq=1, log=False):                    
        tempWord = 0
        tempByte = bytes(0)
        
        tempWord = self._readWord(self.defs.regInputDisable)[0]
        tempWord |= (1<<pin)
        
        #Disable pull-up
        tempWord = self._readWord(self.defs.regPullUp)[0]
        tempWord |= (1<<pin)        
        self._writeWord(addr=self.defs.regPullUp, val=tempWord)
        
        # Set direction to output (REG_DIR_B)
        tempWord = self._readWord(self.defs.regDir)[0]
        tempWord &= ~(1<<pin); #0=output  
        self._writeWord(addr=self.defs.regDir, val=tempWord)

        # Enable oscillator (REG_CLOCK)
        tempByte = self._readByte(self.defs.RegClock)
        tempByte |= (1<<6) # Internal 2MHz oscillator part 1 (set bit 6)
        tempByte &= ~(1<<5)    # Internal 2MHz oscillator part 2 (clear bit 5)
        self._writeByte(self.defs.RegClock, tempByte)

    def _read(self, addr):
        readMem = None
        try:
            readMem = self._i2c.readfrom_mem_into(self._addr, addr, self._buf1)
        except:
            pass
        return readMem

    def _pindir(self, pin, inOut):                    
        modeBit = False
        
        if ((inOut == self.defs.OUTPUT) or (inOut == self.defs.ANALOG_OUTPUT)):
            modeBit = False
        else:
            modeBit = True                 
            
        tempRegDir = self._readWord(addr=self.defs.regDir)[0]
        if (modeBit):
            tempRegDir = (1<<pin)
        else:
            tempRegDir &= ~(1<<pin)

        self._writeWord(addr=self.defs.regDir, val=tempRegDir)

        # If INPUT_PULLUP was called, set up the pullup too:
        if (inOut == INPUT_PULLUP):
            self._writePin(pin, HIGH)
        
        if (inOut == ANALOG_OUTPUT):
            self._ledDriverInit(pin)

    def pwm(self, pin, iOn):        
        self._writeByte(self.defs.RegIOn[pin], iOn)

    def __pwm__nietgebruiken(self, index, on=None, off=None):
        if(on is None or off is None):
            try:
                data = self._i2c.readfrom_mem(self.addr, 0x06 + 4 * index, 4)
                return ustruct.unpack('<HH', data)
            except:
                pass
        data = ustruct.pack('<HH', on, off)
        try:
            self._i2c.writeto_mem(self.addr, 0x06 + 4 * index,  int(val).to_bytes(data, "little"))
        except:
            pass

    def debounceEnable(pin):                            
        debounceEnable = self._read(addr=self.defs.regDebounceEnable)
        debounceEnable |= (1<<pin)
        self._write(addr=self.defs.regDebounceEnable, val=debounceEnable)        

    def reset(self, hard=True):        
        if(hard):
            regMisc = self._readWord(self.defs.RegMisc)            
            if (regMisc & (1<<2)):
                regMisc &= ~(1<<2)
                self._writeWord(self.defs.RegMisc, regMisc)
            
            rstPin = self.defs.pinRESET
            self.pinMode(rstPin, self.defs.OUTPUT)
            self.digitalWrite(rstPin, self.defs.LOW)
            utime.delay_ms(1)
            self.digitalWrite(rstPin, self.defs.HIGH)
        else:            
            self._writeWord(self.defs.RegReset, 0x12)
            self._writeWord(self.defs.RegReset, 0x34)            

    def _writePin(self, pin, highLow):
        regDir = self.defs.RegDir
        regData = self.defs.RegData
                    
        tempRegDir = self._readWord(addr=regDir)[0]
        
        if ((0xFFFF^tempRegDir)&(1<<pin)): #output mode
            tempRegData = self._readWord(regData)[0]

            if (highLow):
                tempRegData |= (1<<pin)
            else:
                tempRegData &= ~(1<<pin)
            
            self._writeWord(regData, tempRegData)

    def _writeWord(self, addr, val):
        lsb = bytes(0)
        msb = bytes(0)
        msb = ((int(val) & 0xFF00) >> 8)
        lsb = (int(val) & 0xFF00)
        try:
            self._i2c.writeto_mem(self._addr, addr, lsb.to_bytes(1, "little"))
            self._i2c.writeto_mem(self._addr, addr, msb.to_bytes(1, "little"))
        except:
            pass

    def _writeByte(self, addr, val):
        try:
            self._i2c.writeto_mem(self._addr, addr, val.to_bytes(1, "little"))
        except:
            pass

    def digitalWrite(self, pin, highLow):
        self._writePin(pin, highLow)

    def _pinDir(self, pin, inOut):
        regDir = self.defs.RegDir    
            
        modeBit = bytes(0)

        if ((inOut == self.defs.OUTPUT) or (inOut == self.defs.ANALOG_OUTPUT)):
            modeBit = False
        else:
            modeBit = True
        
        tempRegDir = self._readWord(addr=regDir)[0]
        if (modeBit):    
            tempRegDir |= (1<<pin)
        else:
            tempRegDir &= ~(1<<pin)
        
        self._writeWord(regDir, tempRegDir)

        #If INPUT_PULLUP was called, set up the pullup too:
        if (inOut == self.defs.INPUT_PULLUP):
            self._writePin(pin, self.defs.HIGH)

        if (inOut == self.defs.ANALOG_OUTPUT):
            self._ledDriverInit(pin)

    def pinMode(self, pin, inOut):
        self._pinDir(pin, inOut)

    def _readWord(self, addr):
        readValue = 0
        msb = 0
        lsb = 0
        try:
            self._i2c.writeto(self._addr, (0).to_bytes(1, "big"))
            rec1 = self._i2c.readfrom_mem(self._addr, addr, 2)        
            msb = (rec1[0] & 0x00FF) << 8
            lsb = (rec1[1] & 0x00FF)
            readValue = msb , lsb
        except:
            pass
        return readValue

    def _readByte(self, addr):
        val = bytes(0)        
        val = self._readWord(addr=addr)[0]        
        return val

    def _readPin(self, pin):
        regDir = self.defs.RegDir
        regData = self.defs.RegData 
        tempRegDir = self._readWord(addr=regDir)[0]
        # dir: 0.output, 1.input
        #print("readPin:", pin ," tempRegDir=", tempRegDir & (1<<pin))
        
        if (tempRegDir & (1<<pin)):  # If the pin is an input
            tempRegData = self._readWord(addr=regData)[0]
            if (tempRegData & (1<<pin)):
                return 1    
        return 0

    def digitalRead(self, pin):
        return self._readPin(pin)    

    def analogWrite(self, pin, iOn):
        self.pwm(pin, iOn)
        
       
LINE_BLACK = 'B'
LINE_WHITE = 'W'

class LineFollower4():
    defs = SX1508def()
            
    def __init__(self, i2c, line_color=LINE_BLACK, addr=0x20):
        self._i2c = i2c
        self._addr = addr
        self._line_color = line_color
        # config pin i/o : 1=input, 0=output
        try:
            self._i2c.writeto_mem(self._addr, self.defs.RegDir, b'\xff')
        except:
            pass
        self.R1 = None
        self.R2 = None
        self.L1 = None
        self.L2 = None
        self.pins_data = ''
                
    def readConfig(self):
        try:
            dirA = self._i2c.readfrom_mem(self._addr, self.defs.RegDir, 1)
            return self._byteToBinaryStr(dirA)
        except:
            pass                    

    def _writePin(self, pin, highLow):
        regDir = self.defs.RegDir
        regData = self.defs.RegData                    
        tempRegDir = self._readWord(addr=regDir)[0]        
        if ((0xFFFF^tempRegDir)&(1<<pin)): #output mode
            tempRegData = self._readWord(regData)[0]
            if (highLow):
                tempRegData |= (1<<pin)
            else:
                tempRegData &= ~(1<<pin)            
            self._writeWord(regData, tempRegData)

    def _writeWord(self, addr, val):
        lsb = bytes(0)
        msb = bytes(0)
        msb = ((int(val) & 0xFF00) >> 8)
        lsb = (int(val) & 0xFF00)
        try:
            self._i2c.writeto_mem(self._addr, addr, lsb.to_bytes(1, "little"))
            self._i2c.writeto_mem(self._addr, addr, msb.to_bytes(1, "little"))
        except:
            pass
        
    def _readWord(self, addr):
        readValue = 0
        msb = 0
        lsb = 0
        try:
            self._i2c.writeto(self._addr, (0).to_bytes(1, "big"))
            rec1 = self._i2c.readfrom_mem(self._addr, addr, 2)        
            msb = (rec1[0] & 0x00FF) << 8
            lsb = (rec1[1] & 0x00FF)
            readValue = msb , lsb
        except:
            pass
        return readValue
    
    def SingleValue(self):
        if self._line_color == LINE_BLACK:
            return self.SensorDataLineBlack()
        else:
            return self.SensorDataLineWhite()
        
    def PinsValue(self):
        val = self.SingleValue()
        return self.toPinValue(val)
    
    def SensorDataLineWhite(self):
        try:
            val = self._i2c.readfrom_mem(self._addr, self.defs.RegData, 1)
            sensor_data = '{0:04b}'.format(val[0])
            return sensor_data
        except:
            pass
        return ''
    
    def SensorDataLineBlack(self):
        try:
            val = self._i2c.readfrom_mem(self._addr, self.defs.RegData, 1)
            _data = '{0:04b}'.format(val[0])
            sensor_data = ''
            tmp = '1' if _data[0]=='0' else '0'
            sensor_data += tmp
            tmp = '1' if _data[1]=='0' else '0'
            sensor_data += tmp
            tmp = '1' if _data[2]=='0' else '0'
            sensor_data += tmp
            tmp = '1' if _data[3]=='0' else '0'
            sensor_data += tmp
            return sensor_data
        except:
            pass
        return ''     
    
    def toPinValue(self, val):        
        if val == '':
            return -1, -1, -1, -1        
        v0 = int(val[0])
        v1 = int(val[1])
        v2 = int(val[2])
        v3 = int(val[3])
        return v3, v2, v1, v0
        
    def valify(self):
        if -1 in [self.L2, self.L1, self.R1, self.R2]:
            return False
        return True
    
    def read(self):
        val = self.SingleValue()        
        self.L2, self.L1, self.R1, self.R2 = self.toPinValue(val)
        self.pins_data = f'{self.L2}{self.L1}{self.R1}{self.R2}'
        
    @property
    def value(self):
        return self.L2, self.L1, self.R1, self.R2
    
    @property
    def data(self):
        return self.pins_data
        


if __name__ == "__main__":
    import time
    i2c = I2C(0, scl=Pin('I2C0_SCL'), sda=Pin('I2C0_SDA'))
    sensor = LineFollower4(i2c)
    
    while True:
        # face to bot front, data order by left to right
        # Ex. 1001 = S
        #data = sensor.SensorValue()            
        #L2,L1,R1,R2 = sensor.toPinValue(data)
        sensor.read()        
        if sensor.valify():            
            print(sensor.data)            
            L2,L1,R1,R2 = sensor.value
            #print(L2,L1,R1,R2)
        else:
            print('Invalid data')
        time.sleep(0.1)
