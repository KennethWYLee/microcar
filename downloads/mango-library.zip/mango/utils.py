####################################################################
# 常數定義
####################################################################
COLOR_BLACK = (0, 0, 0)
COLOR_RED = (255, 0, 0)
COLOR_YELLOW = (255, 150, 0)
COLOR_GREEN = (0, 255, 0)
COLOR_CYAN = (0, 255, 255)
COLOR_BLUE = (0, 0, 255)
COLOR_PURPLE = (180, 0, 255)
COLOR_WHITE = (255, 255, 255)
COLORS = [COLOR_BLACK, COLOR_RED, COLOR_YELLOW, COLOR_GREEN, COLOR_CYAN, COLOR_BLUE, COLOR_PURPLE, COLOR_WHITE]


import math
import os

#####################################################################
# 公用函數定義
#####################################################################
def file_exists(filename):
    try:
        os.stat(filename)
        return True
    except OSError:
        return False
    
def file_remove(filename):
    os.remove(filename)
    
def map(x, in_min, in_max, out_min, out_max):
    val = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    return val

def map_int(x, in_min, in_max, out_min, out_max):
    val = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min    
    return int(val)

def pointToDistance(x2, y2):
    # d = sqrt(pow(a,2)+pow(b,2))
    x1 = 0
    y1 = 0
    a = math.pow(x1 - x2, 2)
    b = math.pow(y1 - y2, 2)
    d = math.sqrt(a + b)
    return d

def pointToAngle(x2, y2):
    # 一點與0點之間的角度
    x1 = 0
    y1 = 0
    radians = math.atan2((y2 - y1), (x2 - x1))
    angle = radians * 180 / math.pi
    return angle

def enum(**enums: int):
    return type('Enum', (), enums)

def hex_to_rgb(value):
    value = value.lstrip('#')
    lv = len(value)
    return tuple(int(value[i:i + lv // 3], 16) for i in range(0, lv, lv // 3))

def rgb_to_hex(value):
    return '#%02x%02x%02x' % value

def is_hex_rgb(value):
    if type(value) is tuple:
        return False
    return value.startswith('#')

def get_type(value):
    type=None
    if isinstance(value, int):
        type = "int"
    elif isinstance(value, str):
        type = "str"
    elif isinstance(value, float):
        type = "float"
    elif isinstance(value, list):
        type = "list"
    elif isinstance(value, tuple):
        type = "tuple"
    elif isinstance(value, dict):
        type = "dict"
    elif isinstance(value, set):
        type = "set"
    return type

def get_string(value):
    t = get_type(value);
    s = None
    if(t == "int" or t == "float"):
        s = str(value)
    else:
        s = value
    return s

def hex_to_string(data):
    try:
        s = bytes.fromhex(data).decode('utf-8')
        return s
    except:
        return ''
    
def byte_to_hex(value):
    return '%02x' % value