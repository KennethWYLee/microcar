from mango import motor
from mango import utils
import mangoblock
import time


class Motion:
    STOP = 0
    FORWARD = 1
    BACKWARD = 2
    RIGHT = 3
    LEFT = 4
    ROT_LEFT = 5
    ROT_RIGHT = 6
    RUN_DUTY = 7
    
    
class MangoBot:    
    
    def __init__(self, m1, m2):
        self.m1 = m1 # right
        self.m2 = m2 # left
        self.state = 0 # 0.init, 1:running
        self.stop = 0 # 1.break
        self.start_tick = 0
        self._delta_time = 0
        self._max_speed = 100
        self._min_speed = 15
        self._speed = 50
        self._last_act = Motion.STOP
        self._last_duty1 = 0
        self._last_duty2 = 0
        self.rc_run = False
        self.rc_callback = None
        
    @property
    def last_action(self):
        return self._last_act
    
    @property
    def delta_time(self):
        self._delta_time = time.ticks_diff(self.start_tick, time.ticks_ms())
        return self._delta_time
    
    @property
    def max_speed(self):
        return self._max_speed
    
    @property
    def min_speed(self):
        return self._min_speed
    
    @max_speed.setter
    def max_speed(self, value):
        self._max_speed = value
        
    @min_speed.setter
    def min_speed(self, value):
        self._min_speed = value
                
    def init_motor(self, m=1, ma=8, mb=9):
        if m == 1:
            self.m1 = motor.DCMotor(ma, mb)
        elif m == 2:
            self.m2 = motor.DCMotor(ma, mb)
            
    def set_motors(self, m1, m2):
        self.m1 = m1
        self.m2 = m2
            
    def start(self):
        self.state = 1 # 0.init, 1:running
        self.stop = 0 # 1.break
        self.start_tick = time.ticks_ms()
        
    def stop(self):
        self.state = 0 # 0.init, 1:running
        self.stop = 1 # 1.break
        self.start_tick = 0
        
    def reset_ticks(self):
        self.start_tick = time.ticks_ms()
                
    def speed(self, value):
        if value > self._max_speed:
            value = self._max_speed
        if value < self._min_speed:
            value = self._min_speed
        self._speed = value
        self.run_last_action()
        
    def forward(self):                  
        self._last_act = Motion.FORWARD
        self.m1.speed(self._speed)
        self.m2.speed(self._speed)
        
    def backward(self):                   
        self._last_act = Motion.BACKWARD
        self.m1.speed(-self._speed)
        self.m2.speed(-self._speed)
        
    def turn_left(self):                  
        self._last_act = Motion.LEFT
        self.m1.speed(self._speed)
        self.m2.speed(0)
        
    def turn_right(self):                  
        self._last_act = Motion.RIGHT
        self.m1.speed(0)
        self.m2.speed(self._speed)
        
    def rot_left(self):                  
        self._last_act = Motion.ROT_LEFT
        self.m1.speed(self._speed)
        self.m2.speed(-self._speed)
        
    def rot_right(self):                  
        self._last_act = Motion.ROT_RIGHT
        self.m1.speed(-self._speed)
        self.m2.speed(self._speed)
        
    def motor_stop(self):
        self._last_act = Motion.STOP
        self.speed(0)
        self.m1.stop()
        self.m2.stop()
        
    def motor_brakes(self):
        self._last_act = Motion.STOP
        self.speed(0)
        self.m1.stop()
        self.m2.stop()
        
    def get_duty_speed(self, percent):
        speed = (percent * self._speed) / 100
        return int(speed)
    
    def run(self, duty1, duty2):
        self._last_act = Motion.RUN_DUTY
        self._last_duty1 = duty1
        self._last_duty2 = duty2
        self.m1.speed(self.get_duty_speed(duty1))
        self.m2.speed(self.get_duty_speed(duty2))
        
    def run_last_action(self):
        if self._last_act == Motion.FORWARD:
            self.forward()
        elif self._last_act == Motion.BACKWARD:
            self.backward()
        elif self._last_act == Motion.LEFT:
            self.turn_left()
        elif self._last_act == Motion.RIGHT:
            self.turn_right()
        elif self._last_act == Motion.ROT_LEFT:
            self.rot_left()
        elif self._last_act == Motion.ROT_RIGHT:
            self.rot_right()
        elif self._last_act == Motion.RUN_DUTY:
            self.run(self._last_duty1, self._last_duty2)
        
    def ir_drive(self, key):
        if key == '1':
            self.speed(20)
            self.run_last_action()
        elif key == '2':
            self.speed(30)
            self.run_last_action()
        elif key == '3':
            self.speed(40)
            self.run_last_action()
        elif key == '4':
            self.speed(50)
            self.run_last_action()
        elif key == '5':
            self.speed(60)
            self.run_last_action()
        elif key == '6':
            self.speed(70)
            self.run_last_action()
        elif key == '7':
            self.speed(80)
            self.run_last_action()
        elif key == '8':
            self.speed(90)
            self.run_last_action()
        elif key == '9':
            self.speed(100)
            self.run_last_action()
        elif key == '0':            
            self.motor_stop()
        elif key == '*':
            self.rot_left()
        elif key == '#':
            self.rot_right()
        elif key == 'UP':
            self.forward()
        elif key == 'DOWN':
            self.backward()
        elif key == 'LEFT':
            self.turn_left()
        elif key == 'RIGHT':
            self.turn_right()
        elif key == 'OK':
            if self.rc_run == False:
                self.rc_run = True               
                self.speed(10)
                self.forward()
            else:
                self.rc_run = False
                self.motor_brakes()                
            
    def rc_drive(self, xVal, yVal):
        xValue = abs(xVal)
        yValue = abs(yVal)
        if xValue < 100 and yValue < 100:
            self.motor_stop()            
        elif xValue > yValue:
            if xVal > 0:
                self.turn_right()
            else:
                self.turn_left()
        elif yValue > xValue:
            if yVal > 0:
                self.forward()
            else:
                self.backward()
        else:
            self.motor_stop()
            
    def rc_drive_task(self, cmd, data):
        if self.rc_callback:
            self.rc_callback(cmd, data)
    
    def pid_drive(self):
        pass
        
    # MXRC 資料通訊協定
    # MOT:電機控制
    # SRT:搖桿值(XY)二組, SRV:舵機值S1-S4, LED:16組0/1,
    # RGB:(NNRRGGBB)二組, USR: 16字元使用者自訂
    def rc_cmd_parse(self, cmd, data):        
        print(cmd)
        if cmd == "MOT":
            x = data[0:4]
            y = data[4:8]
            s = data[8:12]
            xVal = 1500 - int(x)
            yVal = int(y) - 1500
            sVal = int(s) - 1500
            print(xVal, yVal, sVal)
            self.speed(sVal)
            self.rc_drive(xVal, yVal)        
        else:
            self.rc_drive_task(cmd, data)

    # IR remote control
    def ir_decode_key(self, data):    
        key_codes = {
            0x45: "1",
            0x46: "2",
            0x47: "3",
            0x44: "4",
            0x40: "5",
            0x43: "6",
            0x07: "7",
            0x15: "8",
            0x09: "9",
            0x19: "0",
            0xD: "#",
            0x16: "*",
            0x18: "UP",
            0x08: "LEFT",
            0x1C: "OK",
            0x5A: "RIGHT",        
            0x52: "DOWN",        
            0x0: "ERROR",
            # Add more key codes based on your remote
        }
        return key_codes.get(data, "UNKNOWN")

    def ir_callback(self, data, addr, ctrl):
        if data < 0:  # Repeat code or error
            pass
        else:
            key = self.ir_decode_key(data)        
            print("Received Key:", key)
            self.ir_drive(key)

    

  
if __name__ == '__main__':
    import time
    import board

    m1 = motor.DCMotor(13, 12, motor.PWM_FREQ)
    m2 = motor.DCMotor(10, 11, motor.PWM_FREQ)
    rc = MangoBot(m1, m2)    
    rc.speed(30)
    rc.forward()
    time.sleep(3)
    rc.backward()
    time.sleep(3) 
    rc.motor_stop()
        
    
        