# LM393 IR Sensor module.
# Author : Chihmin Lo
# Create date : 2023/8/9
# Last update: 2025/5/13
from machine import Pin
import utime


LINE_BLACK = '1'
LINE_WHITE = '0'

# line follower (2 channels)
class LM393:
    # 黑線傳回: 1
    # 白線傳回: 0
    def __init__(self, left_pin=13, right_pin=12):
        self.left_sensor = Pin(left_pin, Pin.IN)
        self.right_sensor = Pin(right_pin, Pin.IN)
        self._left_value = 0
        self._right_value = 0
        
    def port(self, port_num=1):
        if port_num == 1:
            self.right_sensor = Pin(12, Pin.IN)
            self.left_sensor = Pin(13, Pin.IN)  
        elif port_num == 2:
            self.right_sensor = Pin(14, Pin.IN)
            self.left_sensor = Pin(15, Pin.IN)
            
    def detect(self):
        self._left_value = self.left_sensor.value()
        self._right_value = self.right_sensor.value()

    def read(self):
        self.detect()
        return self._left_value, self._right_value
            
    @property
    def left_ir(self):
        return self.left_sensor.value()
    
    @property
    def right_ir(self):
        return self.right_sensor.value()

    @property
    def left_value(self):
        return self.left_sensor.value()
    
    @property
    def right_value(self):
        return self.right_sensor.value()
    

if __name__ == '__main__':
    sensor = LM393()
    sensor.port(1)
    while True:
        #left_value, right_value = sensor.read()
        print(sensor.left_value)
        print(sensor.right_value)
        utime.sleep(0.1)