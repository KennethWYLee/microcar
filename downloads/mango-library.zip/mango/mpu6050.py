
import machine


class accel():
    def __init__(self, i2c, addr=0x68):
        self.iic = i2c
        self.addr = addr        
        self.iic.writeto(self.addr, bytearray([107, 0]))        

    def get_raw_values(self):        
        a = self.iic.readfrom_mem(self.addr, 0x3B, 14)        
        return a

    def get_ints(self):
        b = self.get_raw_values()
        c = []
        for i in b:
            c.append(i)
        return c

    def bytes_toint(self, firstbyte, secondbyte):
        if not firstbyte & 0x80:
            return firstbyte << 8 | secondbyte
        return - (((firstbyte ^ 255) << 8) | (secondbyte ^ 255) + 1)

    def get_values(self):
        raw_ints = self.get_raw_values()
        vals = {}
        vals["AcX"] = self.bytes_toint(raw_ints[0], raw_ints[1])
        vals["AcY"] = self.bytes_toint(raw_ints[2], raw_ints[3])
        vals["AcZ"] = self.bytes_toint(raw_ints[4], raw_ints[5])
        vals["Tmp"] = self.bytes_toint(raw_ints[6], raw_ints[7]) / 340.00 + 36.53
        vals["GyX"] = self.bytes_toint(raw_ints[8], raw_ints[9])
        vals["GyY"] = self.bytes_toint(raw_ints[10], raw_ints[11])
        vals["GyZ"] = self.bytes_toint(raw_ints[12], raw_ints[13])
        return vals  # returned in range of Int16
        # -32768 to 32767

    def val_test(self):  # ONLY FOR TESTING! Also, fast reading sometimes crashes IIC
        from time import sleep
        while 1:
            print(self.get_values())
            sleep(0.05)


class MPU6050:
    def __init__(self, i2c=None):
        self.i2c = i2c       
        self.mpu6x = accel(self.i2c)

    def read(self):
        d = self.mpu6x.get_values()
        x = d['GyX']
        y = d['GyY']
        z = d['GyZ']
        AcX = d['AcX']
        AcY = d['AcY']
        AcZ = d['AcZ']
        return x,y,z,AcX,AcY,AcZ

    def gyroscope(self):
        d = self.mpu6x.get_values()
        x = d['GyX']
        y = d['GyY']
        z = d['GyZ']
        return x,y,z

    def acceleration(self):
        d = self.mpu6x.get_values()        
        AcX = d['AcX']
        AcY = d['AcY']
        AcZ = d['AcZ']
        return AcX,AcY,AcZ


if __name__ == '__main__':
    from mango import bus
    
    acce = MPU6050(bus.i2c)