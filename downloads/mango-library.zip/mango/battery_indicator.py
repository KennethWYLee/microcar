# OLED 電池電量顯示
# date: 2023/12/30
from mango.oled.fonts import ubuntu_mono_20

class BatteryIndicator():
    
    def __init__(self, oled, voltage_sensor):        
        self.oled = oled        
        self.sensor = voltage_sensor       
        self.x = 20
        self.y = 20
        self.w = 60
        self.h = 24

    def draw_battery(self):        
        self.oled.rect(self.x, self.y, self.w, self.h, 1)
        self.oled.rect(self.x-1, self.y-1, self.w+2, self.h+2, 1)
        self.oled.fill_rect(self.x+self.w, self.y+7, 5, 10, 1)
        
    def draw_level_line(self):
        x1 = self.x + 3
        y1 = self.y + 3
        x2 = x1
        y2 = self.y + 20
        for offset in [11,22,33,44,55]:            
            self.oled.line(x1 + offset, y1, x2 + offset, y2, 0)

    def draw_level(self):
        voltage = self.sensor.measure()
        per = self.sensor.voltage_percentage(voltage)
        per = round(per)
        print(f'voltage={voltage}, percentage={per}')
        x2 = self.x + 3
        y2 = self.y + 3
        w2 = int(round((per * 55 / 100), 0))
        h2 = 18
        self.oled.fill_rect(x2, y2, w2, h2, 1)
        self.oled.text20(f'{per}%', 90, 21)
        
    def draw_level_box(self):
        x1 = self.x + 3
        y1 = self.y + 3
        w = 10
        h = self.h - 6
        for offset in [1, 12,23,34,45]:            
            self.oled.rect(x1 + offset, y1, w, h, 1)
    
    def show(self):
        self.draw_battery()
        self.draw_level()
        self.draw_level_line()
        self.draw_level_box()
        self.oled.show()


if __name__ == '__main__':
    from mango import bus
    from mango import OLED
    from mango.voltage_sensor import VoltageSensor
    import board
        
    oled = OLED(bus.i2c)   
    sensor = VoltageSensor()
    bat = BatteryIndicator(oled, sensor)    
    bat.show()