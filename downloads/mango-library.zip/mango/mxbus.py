from machine import Pin, I2C

i2c = I2C(0, scl=Pin('I2C_SCL'), sda=Pin('I2C_SDA'))

class MangoI2CBus:
    def __init__(self, i2c_id=0):
        self.i2c = None
        if i2c_id == 1:
            self.i2c = I2C(1, scl=Pin('I2C1_SCL'), sda=Pin('I2C1_SDA'))
        else:
            self.i2c = I2C(0, scl=Pin('I2C_SCL'), sda=Pin('I2C_SDA'))
        self.addr = None
        self.shake_addr = 0x00
        self.id_addr = None
            
    def write(self, reg_addr, data, length=1):
        try:
            self.i2c.writeto_mem(self.addr, reg_addr, int(data).to_bytes(length, "little"))
        except:
            pass
        
    def read(self, reg_addr, length=1):
        try:
            data = self.i2c.readfrom_mem(self.addr, reg_addr, length)
            return data
        except:
            return None
    
    def write_word(self, reg_addr, data):
        lsb = bytes(0)
        msb = bytes(0)
        msb = ((int(data) & 0xFF00) >> 8)
        lsb = (int(data) & 0xFF00)
        try:
            self.i2c.writeto_mem(self.addr, reg_addr, lsb.to_bytes(1, "little"))
            self.i2c.writeto_mem(self.addr, reg_addr, msb.to_bytes(1, "little"))
        except:
            pass
        
    def write_byte(self, reg_addr, data):
        try:
            self.i2c.writeto_mem(self.addr, reg_addr, data.to_bytes(1, "little"))
        except:
            pass
        
    def read_word(self, reg_addr):        
        rec = self.i2c.readfrom_mem(self.addr, reg_addr, 2)
        high_bits = rec[0]
        low_bits = rec[1]
        value = (high_bits << 8) + low_bits              
        return value
    
    def read_byte(self, reg_addr):
        val = self.i2c.readfrom_mem(self.addr, reg_addr, 1)
        return val
    
    def shake(self, data=0x00):
        self.write_byte(self.shake_addr, data)
        
    def get_device_id(self):
        dev_id = self.read_byte(self.id_addr)
        return dev_id
    

if __name__ == '__main__':
    import time
    
    def i2c_test():
        bus = MangoI2CBus(1)
        bus.addr = 0x15
        bus.shake_addr = 0x00
        bus.id_addr = 0x0F
        bus.shake()
        time.sleep(0.1)
        dev_id = bus.get_device_id()
        
        print(f"Device ID : {dev_id}")
        if dev_id == b'\x05':
            print('An MXC6655XA device was found.')
    