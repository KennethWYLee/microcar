"""
Buzzer class
Modified: 2021-9-17
by Chih-Min Lo
"""
from machine import Pin, PWM
from utime import sleep, sleep_ms
import math


class Buzzer:
    BUZZ_MODE = 0
    MUSIC_MODE =1
    
    def __init__(self, pin=22, duty=5000, freq=1000):
        self.pin = Pin(pin, Pin.OUT)
        self.pwm = PWM(self.pin) 
        self.pwm.freq(freq)       
        self.duty = duty
        self.stopped = 0
        self.spk = None
        
    def speak_enable_pin(self, pin):
        self.spk = Pin(pin, Pin.OUT)
        
    def play(self, freq_=500, duty_=5000):
        self.pwm.freq(freq_)
        self.pwm.duty_u16(duty_)
        self.stopped = 0
    
    def reset(self):
        self.pwm = PWM(self.pin)

    def release(self):
        self.pwm.deinit()
        self.pin.init(Pin.OUT)
        
    def mode(self, sound_mode=BUZZ_MODE):
        if sound_mode == self.BUZZ_MODE:
            self.release()
        else:
            self.reset()
           
    def start(self):
        self.stopped = 0

    def stop(self):
        self.pwm.duty_u16(0)
        self.stopped = 1
        
    def beep(self):
        self.speaker_on()
        self.pwm.freq(262)
        self.pwm.duty_u16(self.duty)
        sleep_ms(65)
        self.stop()
        self.speaker_off()
        
    def buzz(self, _freq, _duty=None, _duration=0):
        self.pwm.freq(_freq)
        if _duty == None:
            self.pwm.duty_u16(self.duty)
        else:
            self.pwm.duty_u16(_duty)
        if _duration > 0:
            sleep(_duration)
            self.stop()
    
    def sound_siren(self, times=5):
        self.mode(self.BUZZ_MODE)
        self.speaker_on()        
        for i in range(times):  # Repeat 5 times
            self.pin.on()  # Turn the buzzer on
            sleep(0.2)  # Wait for 0.2 seconds
            self.pin.off()  # Turn the buzzer off
            sleep(0.2)  # Wait for 0.2 seconds
        self.speaker_off()
                
    def speak(self, on=True):
        if self.spk != None:
            # 0=enable, 1=disable
            if on:
                self.spk.value(0)
            else:
                self.spk.value(1)
        self.pwm.duty_u16(0)
        
    def speaker_on(self):
        self.speak(True)
        
    def speaker_off(self):
        self.speak(False)
        
    
# 進行曲速度，每分鐘120拍，也就是0.5秒一拍
#data : "D4 8" => note, beats, "P 4" => mute, beats; 
class MusicPlayer(Buzzer):
    # MIDI
    NOTE = {'C':12,'C#':13,'D':14,'D#':15,'E':16,'F':17,'F#':18,'G':19,'G#':20,'A':21,'A#':22,'B':23}
    
    def __init__(self, pin=22, beats=120):
        super().__init__(pin=pin, duty=5000, freq=1000)        
        self.tempo = (60/beats)*1000
        self.melody = []
        
    def reset_melody(self):
        self.melody = []
        
    def add_melody(self, note_data):
        self.melody.append(data)
    
    def set_beats(self, beats):
        self.tempo = (60 / beats) * 1000

    def set_duty(self, duty):
        self.duty = duty        
    
    def get_note_number(self, key):
        if self.NOTE.get(key) is not None:
            return self.NOTE[key]
        return 0
    
    def beat_to_duration(self, beats):
        duration = int(float(beats) * self.tempo)
        return duration
        
    def note_to_freq(self, note):
        freq = math.pow(2, (note-69)/12)*440
        return int(freq)
    
    def data_parsing(self, data):
        l = len(data)
        key = data[:l-1]
        octave = int(data[-1])
        return key, octave
    
    def mute(self, beats):
        self.pwm.duty_u16(0)
        duration = self.beat_to_duration(beats)
        sleep_ms(duration)
        
    def play_note(self, data):
        note_data = data[0]
        beat = data[1]
        if (note_data == "P"):
            self.mute(beat)
        else:
            key, octave = self.data_parsing(note_data)
            note = self.get_note_number(key)
            note += (octave * 12)
            freq = self.note_to_freq(note)            
            duration = self.beat_to_duration(beat)
            self.pwm.freq(freq)
            self.pwm.duty_u16(self.duty)
            sleep_ms(duration)
    
    def play_tone(self, note_data):
        data = note_data.split(' ')
        if len(data) > 1:
            if (data[0] == "P"):
                self.mute(data[1])
            else:
                key, octave = self.data_parsing(data[0])
                note = self.get_note_number(key)
                note += (octave * 12)
                freq = self.note_to_freq(note)
                beats = data[1]
                duration = self.beat_to_duration(beats)
                self.pwm.freq(freq)
                self.pwm.duty_u16(self.duty)
                sleep_ms(duration)
        else:
            print("data error")
                            
    def play_song(self, song=None):
        if song == None:
            song = self.melody
        try:
            self.start()
            for note in song:
                self.play_tone(note)
            self.stop()
        except KeyboardInterrupt:
            self.mute(1)
            self.release()
            
    def sound_emergency1(self, times=10):        
        self.speaker_on()
        for i in range(times):
            self.play_note(["C4", 0.5])
            self.play_note(["E4", 0.5])
        self.speaker_off()
        
    def sound_emergency2(self, times=10):        
        self.speaker_on()
        for i in range(times):
            self.play_note(["C4", 0.5])
            self.play_note(["G4", 0.5])
        self.speaker_off()
        
    def sound_emergency3(self, times=10):        
        self.speaker_on()
        for i in range(times):
            self.play_note(["A4", 0.5])
            self.play_note(["E4", 0.5])
        self.speaker_off()
        
    def sound_school(self, times=2):        
        self.speaker_on()
        for i in range(times):
            self.play_note(["C5", 1])
            self.play_note(["E5", 1])
            self.play_note(["D5", 1])
            self.play_note(["G5", 1])
            self.play_note(["C5", 1])
            self.play_note(["D5", 1])
            self.play_note(["E5", 1])
            self.play_note(["C5", 1])
            self.play_note(["P", 1])
        self.speaker_off()
        
    def sound_effect(self, code):
        if code == 1:
            self.sound_emergency1()
        elif code == 2:
            self.sound_emergency2()
        elif code == 3:
            self.sound_emergency3()
        elif code == 4:
            self.sound_school()
          

class MidiPlayer(MusicPlayer):
    def __init__(self, pin=28, en=29, beats=120):
        super().__init__(pin=pin, beats=beats)        
        self.speak_enable_pin(en)
    
    
    
            
if __name__ == '__main__':
    import board
    buzzer = MidiPlayer(pin=board.BUZZER, en=10, beats=60)    
    buzzer.set_duty(65000) #設定音量
    
    def play_song():
        melody = [
        "E5 0.125", "E5 0.125", "E5 0.25",
        "E5 0.125", "E5 0.125", "E5 0.25",
        "E5 0.125", "G5 0.125", "C5 0.125", "D5 0.125",
        "E5 0.5",
        "F5 0.125", "F5 0.125", "F5 0.125", "F5 0.125",
        "F5 0.125", "E5 0.125", "E5 0.125", "E5 0.0625", "E5 0.0625",
        "E5 0.125", "D5 0.125", "D5 0.125", "E5 0.125",
        "D5 0.25", "G5 0.25"
        ]
        for i in range(3):
            buzzer.play_song(melody)
        buzzer.stop()
        buzzer.release()
        
    def play_melody():
        #buzzer.speaker_on()
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.25])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.25])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['G5',0.125])
        buzzer.play_note(['C5',0.125])
        buzzer.play_note(['D5',0.125])        
        buzzer.play_note(['E5',0.5])
        buzzer.play_note(['P',1])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.25])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['E5',0.25])
        buzzer.play_note(['E5',0.125])
        buzzer.play_note(['G5',0.125])
        buzzer.play_note(['C5',0.125])
        buzzer.play_note(['D5',0.125])        
        buzzer.play_note(['E5',0.5])
        #buzzer.speaker_off()
            
    def sound_demo():        
        buzzer.speaker_on()
        for i in range(5):
            buzzer.play_note(["C6", 0.5])
            buzzer.play_note(["E6", 0.5])
            #buzzer.play_note(["P", 1])            
        buzzer.speaker_off()
          
    ############ demo ################
    play_melody()
    #buzzer.speaker_on()
    #for i in range(5):
    #    buzzer.buzz(262, 5000, 0.5)
    #    buzzer.buzz(392, 5000, 0.5)
    #sleep(2)
    #buzzer.speaker_off()
    #sound_demo()