import array, utime as time
import rp2
from machine import Pin
from mango import utils
import board


COLOR_BLACK = (0, 0, 0)
COLOR_RED = (255, 0, 0)
COLOR_YELLOW = (255, 150, 0)
COLOR_GREEN = (0, 255, 0)
COLOR_CYAN = (0, 255, 255)
COLOR_BLUE = (0, 0, 255)
COLOR_PURPLE = (180, 0, 255)
COLOR_WHITE = (255, 255, 255)
COLORS = [COLOR_BLACK, COLOR_RED, COLOR_YELLOW, COLOR_GREEN, COLOR_CYAN, COLOR_BLUE, COLOR_PURPLE, COLOR_WHITE]

# PIO state machine for RGB. Pulls 24 bits (rgb -> 3 * 8bit) automatically
@rp2.asm_pio(sideset_init=rp2.PIO.OUT_LOW, out_shiftdir=rp2.PIO.SHIFT_LEFT, autopull=True, pull_thresh=24)
def ws2812():
    T1 = 2
    T2 = 5
    T3 = 3
    wrap_target()
    label("bitloop")
    out(x, 1)               .side(0)    [T3 - 1]
    jmp(not_x, "do_zero")   .side(1)    [T1 - 1]
    jmp("bitloop")          .side(1)    [T2 - 1]
    label("do_zero")
    nop()                   .side(0)    [T2 - 1]
    wrap()


class WS2812B:    
    # Configure the number of WS2812 LEDs.
    def __init__(self, pin=7, leds=8, sm_id=4, brightness=0.2):        
        self.num_leds = leds
        self.pin_num = pin
        self.brightness = brightness
        # Create the StateMachine with the ws2812 program, outputting on pin
        self.sm = rp2.StateMachine(sm_id, ws2812, freq=8000000, sideset_base=Pin(self.pin_num))
        # Start the StateMachine, it will wait for data on its FIFO.
        self.sm.active(1)
        # Display a pattern on the LEDs via an array of LED RGB values.
        self.ar = array.array("I", [0 for _ in range(self.num_leds)])
        
    def set_state_machine(self, sm_id):
        self.sm.active(0)
        self.sm = rp2.StateMachine(sm_id, ws2812, freq=8000000, sideset_base=Pin(self.pin_num))
        self.sm.active(1)

    def set_brightness(self, value):
        # value = 0~100 map to 0~1
        value = utils.map(value, 0, 100, 0, 1)
        self.brightness = value

    def show(self):
        dimmer_ar = array.array("I", [0 for _ in range(self.num_leds)])
        for i,c in enumerate(self.ar):
            r = int(((c >> 8) & 0xFF) * self.brightness)
            g = int(((c >> 16) & 0xFF) * self.brightness)
            b = int((c & 0xFF) * self.brightness)
            dimmer_ar[i] = (g<<16) + (r<<8) + b
        self.sm.put(dimmer_ar, 8)
        
    def set_pixels(self, i, color):
        if i< 0 or i > (self.num_leds-1):
            return
        if type(color) != tuple:
            if utils.is_hex_rgb(color):
                color = utils.hex_to_rgb(color)
        self.ar[i] = (color[1]<<16) + (color[0]<<8) + color[2]
        
    def fill(self, color):
        for i in range(len(self.ar)):
            self.set_pixels(i, color)
            
    def set_one(self, idx, color):
        self.set_pixels(idx, color)

    def set_all(self, color):
        self.fill(color)

    def set_range(self, start_idx, end_idx, color):
        for i in range(start_idx, end_idx):
            self.set_pixels(i, color)

    def show_one(self, idx, color):
        self.set_pixels(idx, color)
        self.show()

    def show_all(self, color):
        self.fill(color)
        self.show()

    def show_range(self, start_idx, end_idx, color):
        for i in range(start_idx, end_idx):
            self.set_pixels(i, color)
        self.show()
   
    def close(self):
        color = (0, 0, 0)
        self.fill(color)
        self.show() 

    def set_array(self, colors):
        idx = 0
        for c in colors:
            self.set_pixels(idx, c)
            idx = idx + 1
            
    def set_array_hex(self, hex_colors):
        colorList = []
        for h in hex_colors:
            c = utils.hex_to_rgb(h)
            colorList.append(c)        
        self.set_array(colorList)
        
    def show_array_hex(self, colors):
        self.set_array_hex(colors)
        self.show()


    ##################################################################
    # examples
    ##################################################################
    def color_chase(self, color, wait_ms=1):
        for i in range(self.num_leds):
            self.set_pixels(i, color)            
            self.show()
            time.sleep_ms(wait_ms)

    def chase_range(self, color, index_from, index_to, wait_ms=1):
        for i in range(index_from, index_to+1):
            self.set_pixels(i, color)
            time.sleep_ms(wait_ms)
            self.show()        
    
    def wheel(self, pos):
        # Input a value 0 to 255 to get a color value.
        # The colours are a transition r - g - b - back to r.
        if pos < 0 or pos > 255:
            return (0, 0, 0)
        if pos < 85:
            return (255 - pos * 3, pos * 3, 0)
        if pos < 170:
            pos -= 85
            return (0, 255 - pos * 3, pos * 3)
        pos -= 170
        return (pos * 3, 0, 255 - pos * 3)
        
    def rainbow_cycle(self, wait_ms=1):
        for j in range(255):
            for i in range(self.num_leds):
                rc_index = (i * 256 // self.num_leds) + j
                self.set_pixels(i, self.wheel(rc_index & 255))
            self.show()
            time.sleep_ms(wait_ms)   

    def following(self, color):
        rgb_color = color
        if utils.is_hex_rgb(color):
            rgb_color = utils.hex_to_rgb(color)        
        for i in range(self.num_leds):
            self.close()
            self.set_pixels(i, rgb_color)
            self.show()
            utime.sleep(0.4)
        self.close()


if __name__ == '__main__':
    import time
    from mango import utils
    rgb = WS2812B(sm_id=4, pin=11)
    colorList = ['#ff0000','#ff6600','#ffff00','#009900','#000099','#33ccff','#6600cc','#cc33cc']
    rgb.set_brightness(30)
    rgb.show_array_hex(colorList)
    time.sleep(2)
    # following
    rgb.close()
    for color in COLORS:
        for i in range(rgb.num_leds):
            if i == 0:
                rgb.set_pixels(7, COLOR_BLACK)
            else:
                rgb.set_pixels(i-1, COLOR_BLACK)
            rgb.set_pixels(i, color)
            rgb.show()
            time.sleep(0.2)
    rgb.show_array_hex(colorList)
    time.sleep(1)
    rgb.close()
    # rainbow
    rgb.rainbow_cycle()
    rgb.close()