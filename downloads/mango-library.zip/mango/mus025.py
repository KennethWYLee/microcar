# Sensor Lib.
# Author : Chihmin Lo
# Date   : 2023/8/9
from machine import Pin
import utime
 
# ultrasonic sensor
class MUS025:
    SOUND_SPEED=340
    TRIG_PULSE_DURATION_US=10
    
    def __init__(self, trig_pin=14, echo_pin=15):
        self.trigger = Pin(trig_pin, Pin.OUT)
        self.echo = Pin(echo_pin, Pin.IN)
        self.distance = 0
        
    def port(self, port_num=2):
        if port_num == 1:
            self.trigger = Pin(12, Pin.OUT)
            self.echo = Pin(13, Pin.IN)  
        elif port_num == 2:
            self.trigger = Pin(14, Pin.OUT)
            self.echo = Pin(15, Pin.IN)      
        
    def ping(self):        
        duration = self.detect()
        self.distance = self.calcu_distance(duration)
        return self.distance
    
    def calcu_distance(self, duration, mode="CM"):
        distParam = 0.03432
        if mode == "MM": 
            distParam = 0.3432
        dist = (duration * distParam) / 2
        dist = round(dist, 0)
        return dist
    
    def detect(self):        
        self.trigger.off()
        utime.sleep_us(100)
        self.trigger.on()
        utime.sleep_us(5)
        self.trigger.off()        
        while self.echo.value()==0:
            pulse_start = utime.ticks_us()
        while self.echo.value()==1:
            pulse_end = utime.ticks_us()
        pulse_duration = pulse_end - pulse_start    
        return pulse_duration
    

class UltrasonicSensor:
    SOUND_SPEED=340
    TRIG_PULSE_DURATION_US=10
    
    def __init__(self, trig_pin=14, echo_pin=15):
        self.trigger = Pin(trig_pin, Pin.OUT)
        self.echo = Pin(echo_pin, Pin.IN)
        self.distance = 0
        
    def port(self, port_num=2):
        if port_num == 1:
            self.trigger = Pin(12, Pin.OUT)
            self.echo = Pin(13, Pin.IN)  
        elif port_num == 2:
            self.trigger = Pin(14, Pin.OUT)
            self.echo = Pin(15, Pin.IN)      
        
    def ping(self):        
        duration = self.detect()
        self.distance = self.calcu_distance(duration)
        return self.distance
    
    def calcu_distance(self, duration, mode="CM"):
        distParam = 0.03432
        if mode == "MM": 
            distParam = 0.3432
        dist = (duration * distParam) / 2
        dist = round(dist, 0)
        return dist
    
    def detect(self):        
        self.trigger.off()
        utime.sleep_us(100)
        self.trigger.on()
        utime.sleep_us(5)
        self.trigger.off()        
        while self.echo.value()==0:
            pulse_start = utime.ticks_us()
        while self.echo.value()==1:
            pulse_end = utime.ticks_us()
        pulse_duration = pulse_end - pulse_start    
        return pulse_duration


if __name__ == '__main__':
    sensor = MUS025()
    sensor.port(2)
    while True:
        sensor.ping()
        print(sensor.distance)
        utime.sleep(0.1)