# display text writer
# for OLED
# date: 2024/8/16
import framebuf
from mango.oled import GFX

class Writer:
    '''
    使用英數字庫
    key: ascii
    '''
    def __init__(self, display, font):        
        self.display = display
        self.font = font._FONT

    def _text(self, string, x=0, y=0, color=0xffff, bgcolor=0):        
        buffer = self.display
        font = self.font        
        colors = (color, color, bgcolor, bgcolor)        
        for c in string:
            if not ord(c) in font.keys():
                c = "?"
            row = y            
            _w, * _font = font[ord(c)]
            for byte in _font:
                unsalted = byte
                for col in range(x, x + _w):
                    color = colors[unsalted & 0x03]
                    if color is not None:
                        buffer.pixel(col, row, color)
                    unsalted >>= 2                
                row += 1                
            x += _w        

    def _char(self, c, x=0, y=0, color=0xffff, bgcolor=0, colors=None):        
        buffer = self.display
        font = self.font
        if colors is None:
            colors = (color, color, bgcolor, bgcolor)        
        # for c in string:
        if not c in font.keys():
            return 0
        row = y
        _w, * _font = font[c]
        for byte in _font:
            unsalted = byte
            for col in range(x, x + _w):
                color = colors[unsalted & 0x03]
                if color is not None:
                    buffer.pixel(col, row, color)
                unsalted >>= 2
            row += 1
        x += _w
        
    def text(self, string, x, y, color=1):
        bgcolor = 1
        if color == 1:
            bgcolor = 0        
        self._text(string, x, y, color, bgcolor)
        
    def menu_text(self, string, x, y, height, selected=False):        
        color = 1
        bgcolor = 0
        if selected:
            color = 0
            bgcolor = 1
            self.display.fill_rect(0, y, 128, height, bgcolor)
        self._text(string, x, y, color, bgcolor)


class CubicWriter:
    '''
    使用Cubic中英文字庫
    key: string
    data: bytearray
    '''
    def __init__(self, display, font=None, height=13):
        self.display = display
        self.font = font
        self.words = None
        if self.font != None:
            self.words = font.words
        self.font_height = height
        self.gfx = GFX(display.width, display.height, display.pixel)
        
    def set_words(self, words):
        self.words = words
        
    def text(self, string, x, y, invert=False):
        if self.words == None:
            return
        height = self.font_height
        wordsBuf = []
        #wordsBuf = [self.words[f"'{ord(each)}'"] for each in string]
        for c in string:
            key = f"{ord(c)}"
            if not key in self.words.keys():
                print(f"key={key}, char={c}")            
            wordsBuf.append(self.words[key])
        for buf in wordsBuf:
            if invert: # 反白
                buf = [b^0xff for b in buf]
            width = len(buf) // 2 #判斷字寬
            fbuf = framebuf.FrameBuffer(bytearray(buf), width, height, framebuf.MONO_VLSB)
            self.display.framebuf.blit(fbuf, x, y)
            x += width            
            if x > 128:
                break
        return x
                
    def menu_text(self, string, x, y, selected=False):
        height = self.font_height
        bgcolor = 0
        start = x
        if selected:            
            bgcolor = 1
            # left padding
            self.gfx.fill_rect(0, y, x, height, bgcolor)
        w = self.text(string, x, y, selected)
        if selected and w < 128:
            # right padding
            x = w
            width = (128 - w) - start + 2
            self.gfx.fill_rect(x, y, width, height, bgcolor)


if __name__ == '__main__':
    from machine import Pin, I2C
    from mango.oled import SSD1306_I2C
    import oled_font as font
    import time
    import board
        
    scl = Pin(board.PIN_SCL) 
    sda = Pin(board.PIN_SDA)
    i2c = I2C(0, scl=scl, sda=sda)
    oled = SSD1306_I2C(128, 64, i2c)
    
    c_write = CubicWriter(oled, font)
    #c_write.set_words(font.words)
    line_height = 13
    oled.fill(0)
    oled.show()    
    c_write.text("一次搞懂", 0, 0)
    c_write.menu_text("自訂程式", 0, 17, True) 
    oled.show()