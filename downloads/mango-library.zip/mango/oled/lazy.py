from mango.oled import Writer, GFX, SSD1306_I2C
from mango.oled.fonts import ubuntu_mono_15, ubuntu_mono_20


########################################################################
class OLED_I2C:

    # ----------------------------------------------------------------------
    def __init__(self, i2c, size=(128, 64)):        
        self.i2c = i2c        
        self.oled = SSD1306_I2C(size[0], size[1], i2c)
        self.gfx = GFX(size[0], size[1], self.oled.pixel)
        self.fonts = {}

    # ----------------------------------------------------------------------
    def write(self, text, pos, font=ubuntu_mono_15):        
        if font.__name__ in self.fonts:
            self.fonts[font.__name__].text(text, *pos)
        else:
            self.fonts[font.__name__] = Write(self.oled, font)
            self.fonts[font.__name__].text(text, *pos)

    # ----------------------------------------------------------------------
    def __getattr__(self, attr):       
        if hasattr(self.oled, attr):
            return getattr(self.oled, attr)
        elif hasattr(self.gfx, attr):
            return getattr(self.gfx, attr)

