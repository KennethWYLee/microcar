from machine import Pin, I2C
import time


_AW9523_ADDR           = 0x5b
_AW9523_REG_CHIPID     = 0x10  # Register for hardcode chip ID
_AW9523_REG_SOFTRESET  = 0x7F  # Register for soft resetting
_AW9523_REG_GCR        = 0x11  # Register for general configuration

_MODE_LED  = 0
_MODE_GPIO = 1
_GPIO_IN   = 1
_GPIO_OUT  = 0

class AW9523B:
    # default mode settings for MangoX3 board
    
    def __init__(self, i2c=None, address=0x5b, debug=1):
        self.debug = debug
        if i2c == None:
            self.i2c = I2C(1, scl=Pin('I2C1_SCL'), sda=Pin('I2C1_SDA'))
        else:
            self.i2c = i2c
        self.address = address
        #self.reset()
        time.sleep(0.1)        
        self.check_chip_id()
        self.port0_last_value = None
        self.port1_last_value = None
        
                
    def binary_str(self, data, length=8, fchar='0'):        
        binStr = '{0:b}'.format(data)
        l = len(binStr)
        for i in range(length-l):
            binStr = "0" + binStr
        return binStr    
          
    def read_byte(self, addr):        
        data = self.i2c.readfrom_mem(self.address, addr, 1)
        return data

    def write_byte(self, addr, *vals):        
        val = bytearray(list(vals))        
        self.i2c.writeto_mem(self.address, addr, val)
        
    # chip id
    def check_chip_id(self):        
        data = self.read_byte(_AW9523_REG_CHIPID)        
        if (list(data) == [0x23]):
            print("Find an AW9523 device")
        else:
            raise AttributeError("Cannot find the AW9523")         
    
    # soft reset
    def reset(self):
        self.write_byte(_AW9523_REG_SOFTRESET, 1)
        
    # PORT 12H 13H, MODE:0(led) 1(gpio)
    def port_mode_switch(self, port, mode):
        reg_addr = 0x12 if port==0 else 0x13
        self.write_byte(reg_addr, 0 if mode==_MODE_LED else 0xff)
        
    def port_mode(self, port, mode_settins):
        reg_addr = 0x12 if port==0 else 0x13
        self.write_byte(reg_addr, mode_settins)
        
    #port:04H 05H , mode:0-out 1-in
    def set_port_direction(self, port, mode):
        reg_addr = 0x04 if port==0 else 0x05
        if(self.debug == 1):
            print("set port%d mode = %s"%(port, "out" if mode==_GPIO_OUT else "in"))
        self.write_byte(reg_addr, 0 if mode==_GPIO_OUT else 0xff)
        
    def port_direction(self, port, dir_settings):
        reg_addr = 0x04 if port==0 else 0x05        
        self.write_byte(reg_addr, dir_settings)
    
    #port:00h 01H
    def get_port_value(self, port):
        reg_addr = 0x00 if port==0 else 0x01
        data = self.read_byte(reg_addr)                 
        return data
    
    #port:02H 03H , mode:0-Llev 0xff-Hlev
    def set_port_value(self, port, val):
        reg_addr = 0x02 if port==0 else 0x03
        if(self.debug == 1):
            print("output port%d val = 0x%x"%(port, val))
        self.write_byte(reg_addr, val)
        
    #port:06h 07h, en:0-enable 1-disable
    def set_port_interrupt(self, port, en=0):
        reg_addr = 0x06 if port==0 else 0x07
        if(self.debug == 1):
            print("enable port%d int = 0x%x"%(port, en))
        self.write_byte(reg_addr, en)
        
    #port:06h 07h, en:0-enable 1-disable
    def clear_port_interrupt(self, port):
        reg_addr = 0x06 if port==0 else 0x07
        if(self.debug == 1):
            print("clear port%d interrupt" %port)
        self.read_byte(reg_addr)

    #port:04H 05H , mode:0-out 1-in
    def set_pin_direction(self, port, pin, mode):
        reg_addr = 0x04 if port==0 else 0x05
        self.write_byte(reg_addr, mode<<pin)
        
    #port:00h 01H
    def get_pin_value(self, port, pin):
        val = self.get_port_value(port)
        data = list(val)        
        return data[0]&(1<<pin)
           
    #port:02H 03H , mode:0-Llev 1-Hlev
    def set_pin_value(self, port, pin, val):
        data = val<<pin
        self.set_port_value(port, data)
        
    #port:06h 07h, en:0-enable 1-uenable
    def set_pin_interrupt(self, port, pin, en):        
        data = en<<pin
        self.set_port_interrupt(port, data)
           
    #AW9523B_REG_GLOB_CTR
    #gpomd=D[4]:0-Open-Drain 1-Push-Pull; just p0
    #iseld[1:0]:00-11(IMAX×1/4,IMAX×2/4, IMAX×3/4,IMAX)
    def port_ctrl(self,  gpomd, isel):
        g = gpomd << 4
        s = isel << 2
        val = g | s
        self.write_byte(_AW9523_REG_GCR, val)    

    # lednum:0x20->0x2F, i: i/255×IMAX, IMAX= 37Ma
    def write_led_value(self, lednum_addr, i):
        self.write_byte(lednum_addr, i)
    
    def get_bit_value(self, data, pin):        
        bitdata = list(data)        
        return bitdata[0]&(1<<pin)  
    
                   
class AW9523_GPIO(AW9523B):
    LED_RED = 8
    LED_GREEN = 9
    LED_BLUE = 10
            
    def __init__(self, i2c=None, address=0x5b):
        super().__init__(i2c, address)
        self.set_led_mode()
        self.led_reset()    
        
    def led_reset(self):
        self.set_led_current(8, 0)
        self.set_led_current(9, 0)
        self.set_led_current(10, 0)
        self.set_led_current(11, 0)        
                            
    def led_on(self, pin):        
        self.set_led_current(pin, 100)
    
    def led_off(self, pin):        
        self.set_led_current(pin, 0)
        
    def led_pwm(self, value):
        self.set_led_current(pin, value)
        
    def get_button_value(self, pin_num):
        port = 0
        pin = pin_num
        if pin_num > 7:
            pin = pin_num - 8
            port = 1
        val = self.get_pin_value(port, pin)
        if val == 0:
            return 1
        else:
            return 0
    
    # pin: 0 ~ 15
    # value: 0 ~ 255    
    def set_led_current(self, pin: int, value: int) -> None:        
        if 0 <= pin <= 7:
            addr = 0x24 + pin
        elif 8 <= pin <= 11:
            addr = 0x20 + pin - 8
        elif 12 <= pin <= 15:
            addr = 0x2C + pin - 12
        else:
            raise ValueError("Pin must be 0 to 15")
        # set value
        if not 0 <= value <= 255:
            raise ValueError("Value must be 0 to 255")        
        self.write_byte(addr, value)
            
    def button_on(self, val):
        r = 1 if val==0 else 0
        return r
    
    def set_default_mode(self):
        # settings for MangoX3-MenuBoard
        # 0.OUTPUT, 1.INPUT
        self.port_mode(0, 0b11111111)
        self.port_mode(1, 0b11111111)
        self.port_direction(0, 0b11111111)
        self.port_direction(1, 0b11111111)
        
    def set_led_mode(self):
        # settings for MangoX3-MenuBoard
        self.port_mode(0, 0b11111111)
        self.port_mode(1, 0b11110000)
        self.port_direction(0, 0b11111111)
        self.port_direction(1, 0b11110000)
        
    def set_big_mode(self):
        # settings for Mango-BigBot
        # 0.OUTPUT, 1.INPUT
        self.port_mode(0, 0b11111111)
        self.port_mode(1, 0b11111111)
        self.port_direction(0, 0b11111111)
        self.port_direction(1, 0b11111111)
        
    def led_blue(self, value):
        self.set_led_current(8, value)
        
    def led_green(self, value):
        self.set_led_current(9, value)
        
    def led_red(self, value):
        self.set_led_current(10, value)
               
        
if __name__ == '__main__':
    from mango import bus
    
    aw1 = AW9523_GPIO(bus.i2c, address=0x58)
        
    def led_demo():
        i = 0
        while True:
            try:
                if i == 0:
                    aw1.led_blue(250)
                    aw1.led_green(250)
                    aw1.led_red(250)
                    i = 1
                else:
                    aw1.led_blue(0)
                    aw1.led_green(0)
                    aw1.led_red(0)
                    i = 0
            except KeyboardInterrupt:
                break
            time.sleep(0.2)
        
        aw1.led_blue(0)
        aw1.led_green(0)
        aw1.led_red(0)
        
        
    def handle_interrupt(pin):
        print('interrupt event')
        
    aw1.set_big_mode()
    aw1.set_port_interrupt(1, 0)
    
    btn = Pin(19, Pin.IN, Pin.PULL_UP)
    btn.irq(trigger=Pin.IRQ_FALLING, handler=handle_interrupt)