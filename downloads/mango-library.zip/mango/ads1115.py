# ADS1115 Library
from machine import I2C, Pin
import utime

# Register variables
_REGISTER_MASK = 0x03
_REGISTER_CONVERT = 0x00
_REGISTER_CONFIG = 0x01
_REGISTER_LOWTHRESH = 0x02
_REGISTER_HITHRESH = 0x03

_OS_MASK = 0x8000
_OS_SINGLE = 0x8000     # Write: Set to start a single - conversion
_OS_BUSY = 0x0000       # Read: Bit = 0 when conversion is in progress
_OS_NOTBUSY = 0x8000    # Read: Bit = 1 when no conversion is in progress

# Channel variables
_MUX_MASK = 0x7000
_MUX_DIFF_0_1 = 0x0000  # Differential P = AIN0, N = AIN1 (default)
_MUX_DIFF_0_3 = 0x1000  # Differential P = AIN0, N = AIN3
_MUX_DIFF_1_3 = 0x2000  # Differential P = AIN1, N = AIN3
_MUX_DIFF_2_3 = 0x3000  # Differential P = AIN2, N = AIN3
_MUX_SINGLE_0 = 0x4000  # Single - ended AIN0
_MUX_SINGLE_1 = 0x5000  # Single - ended AIN1
_MUX_SINGLE_2 = 0x6000  # Single - ended AIN2
_MUX_SINGLE_3 = 0x7000  # Single - ended AIN3

# Gain variables
_PGA_MASK = 0x0E00
_PGA_6_144V = 0x0000    # + /-6.144V range  =  Gain 2/3
_PGA_4_096V = 0x0200    # + /-4.096V range  =  Gain 1
_PGA_2_048V = 0x0400    # + /-2.048V range  =  Gain 2 (default)
_PGA_1_024V = 0x0600    # + /-1.024V range  =  Gain 4
_PGA_0_512V = 0x0800    # + /-0.512V range  =  Gain 8
_PGA_0_256V = 0x0A00    # + /-0.256V range  =  Gain 16

# Mode variables
_MODE_MASK = 0x0100
_MODE_CONTIN = 0x0000   # Continuous conversion mode
_MODE_SINGLE = 0x0100   # Power - down single - shot mode (default)

# Samplerate variables
_DR_MASK = 0x00E0       # ADS1115
_DR_128SPS = 0x0000     # 8 samples per second
_DR_250SPS = 0x0020     # 16 samples per second
_DR_490SPS = 0x0040     # 32 samples per second
_DR_920SPS = 0x0060     # 64 samples per second
_DR_1600SPS = 0x0080    # 128 samples per second (default)
_DR_2400SPS = 0x00A0    # 250 samples per second
_DR_3300SPS = 0x00C0    # 475 samples per second
_DR_860SPS = 0x00E0     # 860 samples per Second

_CMODE_MASK = 0x0010
_CMODE_TRAD = 0x0000    # Traditional comparator with hysteresis (default)
_CMODE_WINDOW = 0x0010  # Window comparator

_CPOL_MASK = 0x0008
_CPOL_ACTVLOW = 0x0000  # ALERT / RDY pin is low when active (default)
_CPOL_ACTVHI = 0x0008   # ALERT / RDY pin is high when active

_CLAT_MASK = 0x0004     # Determines if ALERT / RDY pin latches once asserted
_CLAT_NONLAT = 0x0000   # Non - latching comparator (default)
_CLAT_LATCH = 0x0004    # Latching comparator

_CQUE_MASK = 0x0003
_CQUE_1CONV = 0x0000    # Assert ALERT / RDY after one conversions
_CQUE_2CONV = 0x0001    # Assert ALERT / RDY after two conversions
_CQUE_4CONV = 0x0002    # Assert ALERT / RDY after four conversions
_CQUE_NONE = 0x0003     # Disable the comparator and put ALERT / RDY in high state (default)

# List of all usable gains
_GAINS = [
        _PGA_6_144V,    # 2 / 3x
        _PGA_4_096V,    # 1x
        _PGA_2_048V,    # 2x (default)
        _PGA_1_024V,    # 4x
        _PGA_0_512V,    # 8x
        _PGA_0_256V     # 16x
]

# List of voltage values corresponding to the list of usable gains
_GAINS_V = [
        6.144,          # 2 / 3x
        4.096,          # 1x
        2.048,          # 2x (default)
        1.024,          # 4x
        0.512,          # 8x
        0.256           # 16x
]

# List of the different usable channels
_CHANNELS = [           # CH1|CH2
        _MUX_SINGLE_0,  # (0, None) (default)
        _MUX_SINGLE_1,  # (1, None)
        _MUX_SINGLE_2,  # (2, None)
        _MUX_SINGLE_3,  # (3, None)
        _MUX_DIFF_0_1,  # (0, 1)
        _MUX_DIFF_0_3,  # (0, 3)
        _MUX_DIFF_1_3,  # (1, 3)
        _MUX_DIFF_2_3,  # (2, 3)
]

# List of all usable sample rates
_RATES = [
        _DR_128SPS,     # 8 samples per second
        _DR_250SPS,     # 16 samples per second
        _DR_490SPS,     # 32 samples per second
        _DR_920SPS,     # 64 samples per second
        _DR_1600SPS,    # 128 samples per second (default)
        _DR_2400SPS,    # 250 samples per second
        _DR_3300SPS,    # 475 samples per second
        _DR_860SPS      # 860 samples per Second
]


class ADS1115:
    # default mode = _MODE_CONTIN
    def __init__(self, i2c, adr = 0x48):
        self.i2c = i2c
        self.ads_address = adr
        self.ads_gain = _GAINS[3] # default 2
        self.ads_rate = _RATES[4]
        self.ads_mode = _MODE_CONTIN
        self.ads_gainv = 2
        self.temp2 = bytearray(2)

    def init(self, gain, rate, mode):
        self.set_gain(gain)
        self.set_rate(rate)
        self.set_mode(mode)

    def set_gain(self, gain):        
        self.ads_gain = _GAINS[gain]
        self.ads_gainv = gain

    def set_rate(self, rate):        
        self.ads_rate = _RATES[rate]

    def set_mode(self, mode = _MODE_SINGLE):
        self.ads_mode = mode
            
    def set_single_mode(self, mode = True):       
        if (mode):
            self.ads_mode = _MODE_SINGLE
        else:
            self.ads_mode = _MODE_CONTIN
    
    @property
    def mode(self):
        return self.ads_mode
    
    @mode.setter
    def mode(self, value):
        self.ads_mode = value

    def _write_register(self, reg, val):
        self.temp2[0] = val >> 8
        self.temp2[1] = val & 0xff
        self.i2c.writeto_mem(self.ads_address, reg, self.temp2)

    def _read_register(self, reg):
        self.i2c.readfrom_mem_into(self.ads_address, reg, self.temp2)
        return (self.temp2[0] << 8) | self.temp2[1]

    # Reads any raw value (raw) either from the previously specified channel or from another variable and converts it to voltages.
    def raw_to_v(self, raw):
        v_p_b = _GAINS_V[self.ads_gainv] / 32767
        return round(raw * v_p_b, 2)

    def read(self, channel):
        # Linking of all required data by the bitwise operator 'OR ('|')'.
        config = 0x0000
        config |= _CHANNELS[channel]
        config |= self.ads_gain
        config |= self.ads_rate
        config |= self.ads_mode
        config |= _CQUE_NONE
        # Send the required data to the specified register.
        self._write_register(_REGISTER_CONFIG, config)
        while not self._read_register(_REGISTER_CONFIG) & _OS_NOTBUSY:
            break
        # Reading the returned data.
        res = self._read_register(_REGISTER_CONVERT)
        if (res < 32768):
            return res
        else:
            res = res - 65469
            return res
    
    # Reading multiple ADS1115 channels at once
    def read_channels(self, start=0, end=4):
        res1 = 0
        res2 = 0
        res3 = 0
        res4 = 0
        if (start > 4): start = 4
        if (start < 0): start = 0
        if (end > 4): end = 4
        if (end < 0): end = 0
        for x in range (start, end):
            if (x == 0):
                res1 = self.read(x)
                utime.sleep_ms(1)
            if (x == 1):
                res2 = self.read(x)
                utime.sleep_ms(1)
            if (x == 2):
                res3 = self.read(x)
                utime.sleep_ms(1)
            if (x == 3):
                res4 = self.read(x)
                utime.sleep_ms(1)
        return res1, res2, res3, res4
    

class LineColor:
    BLACK  = '1'
    WHITE  = '0'
    RED    = 'R'
    GREEN  = 'G'
    BLUE   = 'B'
    YELLOW = 'Y'
    
class SensorChannels:
    L0 = 0
    L1 = 1
    L2 = 2
    L3 = 3
    R0 = 4
    R1 = 5
    R2 = 6
    R3 = 7
    
    
class GraySensor4():
    # 四路灰度傳感器     
        
    def __init__(self, i2c, adr=0x48 ):        
        self.ads = ADS1115(i2c, adr)
                
    def read_analog(self):
        s1 = self.ads.read(0)
        utime.sleep_ms(2)
        s2 = self.ads.read(1)
        utime.sleep_ms(2)
        s3 = self.ads.read(2)
        utime.sleep_ms(2)
        s4 = self.ads.read(3)
        utime.sleep_ms(2)        
        return s1, s2, s3, s4
    
    def read_digital(self):
        s1, s2, s3, s4 = self.read_analog()
        s1 = 1 if s1 == 32767 else 0
        s2 = 1 if s2 == 32767 else 0
        s3 = 1 if s3 == 32767 else 0
        s4 = 1 if s4 == 32767 else 0
        return s1, s2, s3, s4
    
    def get_digital_result(self):
        s1, s2, s3, s4 = self.read_digital()
        data = f"{s1}{s2}{s3}{s4}"
        return data


class GraySensor8():
    # 八路灰度傳感器
    # 黑: 32767, 白: 2000~2600, 黃綠: 2600~ 2800
        
    def __init__(self, i2c, digital_channels='ALL'):        
        self.adsL = ADS1115(i2c, adr=0x48)
        self.adsR = ADS1115(i2c, adr=0x49)
        self.adsL.set_rate(7)
        self.adsR.set_rate(7)
        self.adsL.set_gain(2)
        self.adsR.set_gain(2)
        self.adsL.set_single_mode(False)
        self.adsR.set_single_mode(False)
        self.wait = 500 # us
        self.digital_channels = digital_channels
                
    def single_mode(self, mode=True):
        self.adsL.set_single_mode(mode)
        self.adsR.set_single_mode(mode)
        
    def set_ads_mode(self, mode=_MODE_CONTIN):
        self.adsL.mode = mode
        self.adsR.mode = mode
        
    def set_digital_channels(self, channels='ALL'):
        self.digital_channels = channels
        
    def read_channel(self, ch='L1', typ='D'):
        if ch == 'L1':
            value = self.adsL.read(1)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'L2':
            value = self.adsL.read(2)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'L3':
            value = self.adsL.read(3)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'L4':
            value = self.adsL.read(0)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'R1':
            value = self.adsR.read(1)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'R2':
            value = self.adsR.read(2)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'R3':
            value = self.adsR.read(3)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
        elif ch == 'R4':
            value = self.adsR.read(0)
            if typ == 'D':
                data = 1 if value == 32767 else 0
                return data
            return value
                
    def read_analog(self):
        l4 = self.adsL.read(0) #L4
        r4 = self.adsR.read(0) #R4
        utime.sleep_us(self.wait)
        l1 = self.adsL.read(1) #L1
        r1 = self.adsR.read(1) #R1
        utime.sleep_us(self.wait) 
        l2 = self.adsL.read(2) #L2
        r2 = self.adsR.read(2) #R2
        utime.sleep_us(self.wait)
        l3 = self.adsL.read(3) #L3        
        r3 = self.adsR.read(3) #R3        
        return l1, l2, l3, l4, r1, r2, r3, r4
    
    def read_analog_channel(self, channel):
        if channel == 1:
            l = self.adsL.read(1) #L1
            r = self.adsR.read(1) #R1
        elif channel == 2:
            l = self.adsL.read(2) #L2
            r = self.adsR.read(2) #R2
        elif channel == 3:
            l = self.adsL.read(3) #L3        
            r = self.adsR.read(3) #R3
        elif channel == 4:
            l = self.adsL.read(0) #L4
            r = self.adsR.read(0) #R4
        #utime.sleep_us(self.wait)               
        return l,r
    
    def check_digital(self, value):
        chk = 1 if value == 32767 else 0
        return chk
    
    def read_digital(self):
        l1, l2, l3, l4, r1, r2, r3, r4 = self.read_analog()
        # convert to 0 or 1
        l1 = 1 if l1 == 32767 else 0
        l2 = 1 if l2 == 32767 else 0
        l3 = 1 if l3 == 32767 else 0
        l4 = 1 if l4 == 32767 else 0
        r1 = 1 if r1 == 32767 else 0
        r2 = 1 if r2 == 32767 else 0
        r3 = 1 if r3 == 32767 else 0
        r4 = 1 if r4 == 32767 else 0
        return l1, l2, l3, l4, r1, r2, r3, r4
        
    def get_digital_state(self):
        data = ''                    
        if self.digital_channels == '6':
            l1,r1 = self.read_analog_channel(1)
            l1 = self.check_digital(l1)
            r1 = self.check_digital(r1)
            utime.sleep_us(self.wait)
            l2,r2 = self.read_analog_channel(2)
            l2 = self.check_digital(l2)
            r2 = self.check_digital(r2)
            utime.sleep_us(self.wait)
            l3,r3 = self.read_analog_channel(3)
            l3 = self.check_digital(l3)
            r3 = self.check_digital(r3)
            data = f"{l3}{l2}{l1}{r1}{r2}{r3}"
        elif self.digital_channels == '4':
            l1,r1 = self.read_analog_channel(1)
            l1 = self.check_digital(l1)
            r1 = self.check_digital(r1)
            utime.sleep_us(self.wait)
            l2,r2 = self.read_analog_channel(2)
            l2 = self.check_digital(l2)
            r2 = self.check_digital(r2)
            data = f"{l2}{l1}{r1}{r2}"
        else:
            l1, l2, l3, l4, r1, r2, r3, r4 = self.read_digital()
            data = f"{l4}{l3}{l2}{l1}{r1}{r2}{r3}{r4}"
        return data

    @property
    def digital_state(self):
        data = self.get_digital_state()
        return data
    
    def get_mixed_state(self, t='AADDDDAA'):
        l1, l2, l3, l4, r1, r2, r3, r4 = self.read_analog()
        # convert to 0 or 1
        if t[3] == "D":
            l1 = 1 if l1 == 32767 else 0
        if t[2] == "D":
            l2 = 1 if l2 == 32767 else 0
        if t[1] == "D":
            l3 = 1 if l3 == 32767 else 0
        if t[0] == "D":
            l4 = 1 if l4 == 32767 else 0
        if t[4] == "D":
            r1 = 1 if r1 == 32767 else 0
        if t[5] == "D":
            r2 = 1 if r2 == 32767 else 0
        if t[6] == "D":
            r3 = 1 if r3 == 32767 else 0
        if t[7] == "D":
            r4 = 1 if r4 == 32767 else 0        
        return l4,l3,l2,l1,r1,r2,r3,r4
    
    def atod_state(self, l1, l2, l3, l4, r1, r2, r3, r4):        
        # convert to 0 or 1
        l1 = 1 if l1 == 32767 else 0
        l2 = 1 if l2 == 32767 else 0
        l3 = 1 if l3 == 32767 else 0
        l4 = 1 if l4 == 32767 else 0
        r1 = 1 if r1 == 32767 else 0
        r2 = 1 if r2 == 32767 else 0
        r3 = 1 if r3 == 32767 else 0
        r4 = 1 if r4 == 32767 else 0
        data = f"{l4}{l3}{l2}{l1}{r1}{r2}{r3}{r4}"
        return data
    
    def test_color(self, color = LineColor.BLACK, sampling = 100, debug=1):
        print("testing ...")
        min_v = [5,5,5,5,5,5,5,5]
        max_v = [0,0,0,0,0,0,0,0]
        for i in range(sampling):
            data = ads.read()
            for i in range(8):            
                if data[i] < min_v[i]:
                    min_v[i] = data[i]
                if data[i] > max_v[i]:
                    max_v[i] = data[i]        
            sleep_ms(5)
        if debug == 0:
            with open(self.FILE_NAME, 'a') as file:
                for i in range(8):
                    test_result = f"{i},{min_v[i]},{max_v[i]},{color}\n" 
                    file.write(test_result)
                file.close()
        else:
            print(f"color={color}")
            print("--------------------------------------")            
            for i in range(8):
                test_result = f"idx={i},min={min_v[i]},max={max_v[i]}" 
                print(test_result)
            print("--------------------------------------")
        print("test finished")
        

if __name__ == '__main__':
    import time 
    from mango import bus
    from mango import utils
            
    #ads = GraySensor4(i2c=bus.i2c, adr=0x48)
    ads = GraySensor8(i2c=bus.i2c)    
    #ads.mode = _MODE_SINGLE
    ads.set_digital_channels('4')
    d1 = ads.read_digital()
    print(d1)
    print('------------------------')
    while True:
        #d = ads.read_analog()        
        #d = ads.get_mixed_state(t='AADDDDAA')
        d = ads.get_digital_state()
        print(d)
        #l1 = ads.read_channel('L1','A')
        #r1 = ads.read_channel('R1','A')
        #print(l1, r1)        
        time.sleep_ms(1000)
        