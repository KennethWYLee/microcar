# battery voltage indicator with voltage divider
# date: 2023/12/29

from machine import Pin, ADC
from time import sleep

# 12-bit
# measure voltage with an accuracy of 0.025%.
# A Raspberry Pi Pico has 12 Bits ADC with a quantization level of 4096
# adc pin read value, 0-65535 across voltage range 0.0v - 3.3v
# resolution of the ADC is 3.3/4095

class VoltageSensor:
    adc_resolution = 3.3 / 65535
        
    def __init__(self, adc_pin=27, vcc=5, bat_voltage=8.4, adjust_vol=0.02):
        self.vcc = vcc
        self.sensor = ADC(adc_pin)
        self.bat_capacity = bat_voltage
        self.adjust_vol = adjust_vol
        
    def measure(self):
        sensor_value = self.sensor.read_u16()
        voltage = (sensor_value * self.adc_resolution) * self.vcc
        voltage = voltage + self.adjust_vol
        if voltage < 0.3:
            voltage = 0            
        return round(voltage, 2)
    
    def power_percentage(self):
        voltage = self.measue()
        per = voltage / self.bat_capacity
        return round(per, 2)
    
    def voltage_percentage(self, voltage):        
        per = (voltage / self.bat_capacity) * 100
        return round(per, 2)


if __name__ == '__main__':
    sensor = VoltageSensor()
    while True:        
        voltage = sensor.measure()
        per = sensor.voltage_percentage(voltage)
        print(f'voltage={voltage}, percentage={per}')
        sleep(0.1)
