from machine import Pin, UART
from time import sleep, ticks_ms
from array import array
from mango import utils
import binascii


class SerialComm:
    '''
    Protocol for Mango BLE 5.0
    command = 0x??
    data = []
    package format = [0x24, command, 0x3A, data, 0x23, 0x0D, 0x0A]
    '''    
    def extract_data_array(buf):
        l = len(buf)
        nArray = array('i',[0]*l)
        i = 0
        for b in buf:
            nArray[i] = b
            i = i + 1
        return nArray

    def extract_color(buf):
        ary = SerialComm.extract_data_array(buf)    
        l = len(ary)    
        data = tuple(ary[3:l-3])
        return data
        
    def extract_command_data(buf):
        try:
            hex_code = binascii.hexlify(bytearray(buf)).decode('ascii')        
            l = len(hex_code)
            cmd = hex_code[2:4]
            data = hex_code[6:l-6]
            return cmd, data
        except:
            return "",""

    def extract_command(buf):
        try:
            hex_code = binascii.hexlify(bytearray(buf)).decode('ascii')
            cmd = hex_code[2:4]
            return cmd
        except:
            return ""
        
    def extract_data(buf, is_hex=True):
        try:
            hex_code = binascii.hexlify(bytearray(buf)).decode('ascii')        
            l = len(hex_code)        
            data = hex_code[6:l-6]
            if is_hex:
                return data
            else:
                return utils.hex_to_string(data)
        except:
            return ""
        
    def check_command(buf):
        try:
            hex_code = binascii.hexlify(bytearray(buf)).decode('ascii')    
            l = len(hex_code)
            if l < 14:
                return False
            chk_start = hex_code[0:2]        
            chk_split = hex_code[4:6]        
            chk_end = hex_code[l-6:l-4]
            start_code = int(chk_start, 16)
            split_code = int(chk_split, 16)
            end_code = int(chk_end, 16)
            if (start_code == 0x24) and (end_code == 0x23) and (split_code == 0x3A):
                return True
            return False
        except:
            return False
      
    # MXRC 資料通訊協定
    # SRT:搖桿值(XY)二組, SRV:舵機值S1-S4, LED:16組0/1,
    # RGB:(NNRRGGBB)二組, USR: 16字元使用者自訂
    def check_mxrc_command(buf):
        try:
            data = buf.decode('utf-8').strip()
            cmd = data[0:3]
            chk = data[19:20]
            if chk == "#":                
                if cmd == "MOT" or cmd == "SRV" or cmd == "LED" or cmd == "RGB" or cmd == "USR":
                    return True
            return False
        except Exception as e:
            print(e)
        return False    

    def get_mxrc_command(buf):
        cmd = ""
        data = ""
        try:
            data = buf.decode('utf-8').strip()
            cmd = data[0:3]
            chk = data[19:20]            
            return cmd, data[3:19]
        except Exception as e:
            print(e)
        return "", ""
        
    # V7RC APP 資料協定
    def check_v7rc_command(buf):
        try:
            data = buf.decode('utf-8').strip()
            cmd = data[0:3]
            chk = data[19:20]
            if chk == "#":
                if cmd == "SS2" or cmd == "SS4" or cmd == "SRT" or cmd == "SR2" or cmd == "SRV":
                    return True
            return False
        except Exception as e:
            print(e)
        return False    

    def get_v7rc_command(buf):
        cmd = ""
        data = ""
        try:
            data = buf.decode('utf-8').strip()
            cmd = data[0:3]
            chk = data[19:20]
            return cmd, data[3:19]                               
        except Exception as e:
            print(e)
        return "", ""
            
    def hexToInt_s16(data):
        try:
            if len(data) < 4:
                return int(data, 16)        
            int_value = int(data, 16)        
            bits = len(data) * 4        
            if int_value >= (1 << (bits-1)):
                int_value -= 1 << bits
                return int_value
            return None
        except:
            return None
        
    def check_equal(received, data):        
        return (received == data)


class EasyUART():
    
    def __init__(self,uart_num=1, tx_pin=4, rx_pin=5, baudrate=115200):        
        self.txPin=Pin(tx_pin)
        self.rxPin=Pin(rx_pin, Pin.IN, Pin.PULL_UP)
        self.baudrate = baudrate
        self.port = UART(uart_num, baudrate=self.baudrate, tx=self.txPin, rx=self.rxPin)
        self.rx_callback = None
        
    def set_tx_Off(self):
        self.txPin.off()
        
    def set_tx_on(self):
        self.txPin.on()
        
    def irq_open(self):        
        self.rxPin.irq(handler=self.irq_callback, trigger=Pin.IRQ_FALLING)
        
    def irq_close(self):
        self.rxPin.irq(handler=None)
        self.rx_callback = None
        
    def set_irq_callback(self, callback):
        self.rx_callback = callback
        
    def irq_callback(self, pin):
        if self.rx_callback != None:
            self.rx_callback()
            
    def close(self):
        self.irq_close()
        
    def purge_buffer(self):
        while self.port.any():
            self.port.read(1)
            
    def set_tx_off(self):
        self.txPin.off()

    def send(self, cmd):        
        self.port.write(cmd)

    def send_wait_response(self, cmd, timeout=2000):        
        self.port.write(cmd)
        code = self.wait_response(timeout)
        return code
    
    def send_wait_response_line(self, cmd, timeout=2000):        
        self.port.write(cmd)
        return self.wait_response_line(timeout)

    def wait_response(self, timeout=2000):
        prvMills = ticks_ms()
        resp = b""
        while (ticks_ms()-prvMills)<timeout:
            if self.port.any():
                resp = b"".join([resp, self.port.read(1)])
            else:
                break
        return resp

    def wait_response_line(self, timeout=2000):        
        prvMills = ticks_ms()
        line = b""
        while (ticks_ms()-prvMills)<timeout:
            if self.port.any():
                line = line + self.port.readline()
                l = len(line)
                if l > 3:
                    charLast2 = line[l-2:l]                    
                    if charLast2 == b'\r\n':
                        break            
        return line
    
    def read(self):
        buf = self.wait_response_line()
        return buf
    
    def write(self, text):
        self.send(text)
        
    def read_text(self):
        buf = self.wait_response_line()
        data = ""
        try:
            data = buf.decode('utf-8').strip()
        except Exception as e:
            print(e)
        return data
    
    
class BLE(EasyUART):   
    '''
    Protocol for Mango BLE 5.0
    command = 0x??
    data = []
    package format = [0x24, command, 0x3A, data, 0x23, 0x0D, 0x0A]
    '''
    CHAR_NEW_LINE = 0x0a
    CHAR_RETURN = 0x0d
    HEAD_START = 0x24
    HEAD_END = 0x23
    HEAD_MID = 0x3A
    
    SERVICE_UUID = 'FFA0'
    TX_UUID = 'FFA1'
    RX_UUID = 'FFA2'
    TX_UUID_NO_NOTIFY = 'FFA3'
    
    
    def __init__(self, uart_num=1, tx_pin='BLE_TX', rx_pin='BLE_RX', baudrate=115200):
        self._name = None
        super().__init__(uart_num=uart_num, tx_pin=tx_pin, rx_pin=rx_pin, baudrate=baudrate)          
            
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value
        
    def set_name(self, ble_name=None):
        if ble_name == None:
            ble_name = self._name
        data = b'AT+BM'+ble_name+'\r\n'
        resp = self.send_wait_response(data)
        sleep(1)
        
    def set_sppname(self, spp_name=None):
        if spp_name == None:
            return
        data = b'AT+BD'+spp_name+'\r\n'
        resp = self.send_wait_response(data)
        sleep(1)
    
    def set_uuid(self, mode=0):
        robot_mode = "A"
        if mode == 1:
            robot_mode = "B"
        elif mode == 2:
            robot_mode = "C"
        elif mode == 3:
            robot_mode = "D"
        elif mode == 4:
            robot_mode = "E"

        sv_uuid = f"FF{robot_mode}0"
        tx_uuid = f"FF{robot_mode}1"
        rx_uuid = f"FF{robot_mode}2"
        tx_no_uuid = f"FF{robot_mode}3"

        data = b'AT+U0' + sv_uuid + '\r\n'
        resp = self.send_wait_response(data)
        sleep(0.2)
        data = b'AT+U1' + tx_uuid + '\r\n'
        resp = self.send_wait_response(data)
        sleep(0.2)
        data = b'AT+U2' + rx_uuid + '\r\n'
        resp = self.send_wait_response(data)
        sleep(0.2)
        data = b'AT+U3' + tx_no_uuid + '\r\n'
        resp = self.send_wait_response(data)
        sleep(0.2)

    def config(self, blename, mode=0):
        self.set_name(blename)
        self.set_sppname(blename+"_spp")
        self.set_uuid(mode)
        
    

if __name__ == '__main__':
    import mangoblock
    import board
    import time
    from machine import Timer
    
    def ble_demo():
        ble = BLE(uart_num=board.BLE_UART, tx_pin=board.BLE_TX, rx_pin=board.BLE_RX)    
        is_break = False
        file_name = ""
        code_string = ""
        f = None
        while not is_break:
            data = ''
            data = ble.read_text()
            if data != "":
                print(data)
                if SerialComm.check_equal(data,'1'):
                    print("equal")
            sleep(0.1)
         
     
    def ble_demo():
        ble = BLE(uart_num=board.BLE_UART, tx_pin=board.BLE_TX, rx_pin=board.BLE_RX)
        ble.config("X2-L006")
        
    # test
    def uart_demo():
        mangoblock.app.stop_uart()
        uart = EasyUART(uart_num=board.UART, tx_pin=board.TX, rx_pin=board.RX)
        #uart.set_tx_off()
               
        def tick(timer):
            #uart.set_tx_on()
            uart.write("test\n")
            #uart.set_tx_off()
        
        timer1 = Timer(-1)
        timer1.init(freq=2000, mode=Timer.PERIODIC, callback=tick)
        
        while True:
            data = ''
            data = uart.read_text()
            if data != "":
                print(data)                
            sleep(0.1)
            
    def ble_irq_handler():
        print("----- start ------")
        buf = ble.wait_response_line()
        if buf != b'':
            print(buf)
    
    #uart_demo()
    ble = BLE(uart_num=board.BLE_UART, tx_pin=board.BLE_TX, rx_pin=board.BLE_RX)
    #ble.set_irq_callback(ble_irq_handler)
    #ble.irq_open()
    
    ble.config("X2-LJ05")
    print('rename ok')