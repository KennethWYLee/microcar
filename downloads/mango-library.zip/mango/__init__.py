from mango.blex_mgr import *
from mango.bus import *
from mango.icons import *
from mango.sdcard import *
from mango.ble import *
from mango.button import *
from mango.buzzer import *
from mango.display import *
from mango.mus025 import *
from mango.lm393 import *
from mango.ws2812b import *
from mango.servo import *
from mango.battery_indicator import *
from mango.voltage_sensor import *
from mango.rus04 import *
from mango.sx1508 import *
from mango.aw9523 import *
from mango.ads1115 import *
from mango.encoder import *
from mango.motor import *
from mango.pid import *
# OTHER
from mango.mpu6050 import *
from mango.tcs34725 import *
from mango.io_expansion import *
# Bot
from mango.bot import *

API_VERSION = "2.2.1"

def bootloader():
    import machine
    machine.bootloader()
    
#########################################################
# Mango Class
#########################################################
from machine import Pin, PWM, ADC
from mango import utils

INPUT_DIGITAL = 'INPUT_DIGITAL'
INPUT_ANALOG = 'INPUT_ANALOG'
INPUT_PULLUP = 'INPUT_PULLUP'
INPUT_PULLDOWN = 'INPUT_PULLDOWN'
OUTPUT_DIGITAL = 'OUTPUT_DIGITAL'
OUTPUT_ANALOG = 'OUTPUT_ANALOG'
HIGH = 1
LOW = 0
A0 = 26
A1 = 27
A2 = 28
A3 = 29

P = {}

def set_pin_mode(pin, pin_mode):
    if pin_mode == INPUT_DIGITAL:
        P[pin] = Pin(pin, Pin.IN)
    elif pin_mode == INPUT_ANALOG:
        P[pin] = ADC(Pin(pin))
    elif pin_mode == INPUT_PULLUP:
        P[pin] = Pin(pin, Pin.IN, Pin.PULL_UP)
    elif pin_mode == INPUT_PULLDOWN:
        P[pin] = Pin(pin, Pin.IN, Pin.PULL_DOWN)
    elif pin_mode == OUTPUT_DIGITAL:
        P[pin] = Pin(pin, Pin.OUT)
    elif pin_mode == OUTPUT_ANALOG:
        P[pin] = PWM(Pin(pin, Pin.OUT))
        P[pin].freq(1000)
        
def set_analog_pin_freq(pin, value):
    P[pin].freq(value)

def set_pin_irq(pin, callback_handler, falling=True, rising=True):
    trigger_option = Pin.IRQ_RISING|Pin.IRQ_FALLING
    if falling and rising:
        trigger_option = Pin.IRQ_FALLING|Pin.IRQ_RISING
    else:
        if falling:
            trigger_option = Pin.IRQ_FALLING
        else:
            trigger_option = Pin.IRQ_RISING
    P[pin].irq(trigger=trigger_option, handler=callback_handler)
    
def digital_read(pin):
    v = P[pin].value()
    return v

def digital_write(pin, value):
    P[pin].value(value)

def digital_toggle(pin):
    P[pin].toggle()
    
def analog_read(pin):
    x = P[pin].read_u16()
    value = utils.map_int(x, 0, 65535, 0, 255)
    return value

def analog_read_u16(pin):
    v = P[pin].read_u16()
    return v

def analog_write(pin, value):
    duty_value = utils.map_int(value, 0, 255, 0, 65535)
    P[pin].duty_u16(duty_value)

