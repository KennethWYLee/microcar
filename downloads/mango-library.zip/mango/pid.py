import math


# Use 8 channels gray line follower sensor
# 
class Control:
    # kp: related to the proportional control term
    # ki: related to the integral  control term
    # kd: related to the derivative control term
    def __init__(self, kp=20.0, ki=0.001, kd=5.0, base_speed=50):        
        self.max_speed = 100
        self.min_speed = 0
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.base_speed = base_speed
        self.error = 0       
        self.last_error = 0
        self.sum_error = 0
        self.channels = 8
        self.line_width = 30 #30mm
        self.state_error = {}
        
    def set_channels(self, channels):
        self.channels = channels
        
    def set_line_width(self, width):
        self.line_width = width
        
    def set_max_speed(self, value):
        self.max_speed = value
        
    def set_min_speed(self, value):
        self.min_speed = value
        
    def reset_sum_error(self):
        self.sum_error = 0
        
    def reset_error_state(self):
        self.state_error.clear()
        
    def add_error_state(self, state, error):
        self.state_error[state] = error
        
    def default_state_error(self):
        self.state_error.clear()
        self.state_error["00011000"] = 0
        self.state_error["00011100"] = 1
        self.state_error["00001100"] = 2
        self.state_error["00000100"] = 3
        self.state_error["00000110"] = 4
        self.state_error["00000010"] = 5
        self.state_error["00000011"] = 6
        self.state_error["00000001"] = 8
        self.state_error["00111000"] = -1
        self.state_error["00110000"] = -2
        self.state_error["00100000"] = -3
        self.state_error["01110000"] = -4
        self.state_error["01000000"] = -5
        self.state_error["11000000"] = -6
        self.state_error["10000000"] = -8        
    
    def get_error(self, state):  
        if len(self.state_error) == 0:
            self.default_state_error()    
        try:
            error = self.state_error[state]
            return error
        except:
            return None
    
    def equal_last_error(self, error):
        if error == self.last_error:
            return True
        return False
    
    def get_adjust_value(self, error):
        pass
    
    def adjust_speed(self, adjust):
        left_speed = self.base_speed + adjust
        if left_speed > self.max_speed:
            left_speed = self.max_speed
        elif left_speed < self.min_speed:
            left_speed = self.min_speed
            
        right_speed = self.base_speed - adjust
        if right_speed < self.min_speed:
            right_speed = self.min_speed
        elif right_speed > self.max_speed:
            right_speed = self.max_speed
        
        left_speed = int(left_speed)
        right_speed = int(right_speed)
        
        return left_speed, right_speed  
      
      
class PControl(Control):
    
    def __init__(self, kp=21.0, base_speed=50):                
        super().__init__(kp=kp, base_speed=base_speed)
        
    def get_adjust_value(self, error):
        # adjust = Kp * error
        adjust = self.kp * error
        return adjust
    
    
class DControl(Control):
    
    def __init__(self, kd=5.0, base_speed=50):                
        super().__init__(kd=kd, base_speed=base_speed)
        
    def get_adjust_value(self, error):
        # adjust = Kp * error + Kd * (error - previous_error)
        adjust = self.kd * (error - self.last_error)
        self.last_error = error
        return adjust
    
    
class PDControl(Control):
    
    def __init__(self, kp=20.0, kd=5.0, base_speed=50):                
        super().__init__(kp=kp, kd=kd, base_speed=base_speed)
        
    def get_adjust_value(self, error):
        # adjust = Kp * error + Kd * (error - previous_error)
        adjust = self.kp * error + self.kd * (error - self.last_error)
        self.last_error = error
        return adjust
    
        
class PIControl(Control):
    
    def __init__(self, kp=20.0, ki=0.001, base_speed=50):                
        super().__init__(kp=kp, ki=ki, base_speed=base_speed)    
    
    def get_adjust_value(self, error):
        # adjust = Kp * error + Kd * (error – previous_error) + Ki * (sum_error)
        adjust = self.kp * error + self.ki * self.sum_error
        self.last_error = error
        self.sum_error += error
        return adjust
    
    
class PIDControl(Control):
    
    def __init__(self, kp=20.0, ki=0.001, kd=5.0, base_speed=50):                
        super().__init__(kp, ki, kd, base_speed)    
    
    def get_adjust_value(self, error):
        # adjust = Kp * error + Kd * (error – previous_error) + Ki * (sum_error)
        adjust = self.kp * error + self.kd * (error - self.last_error) + self.ki * self.sum_error
        self.last_error = error
        self.sum_error += error
        return adjust
    
       
    
if __name__ == '__main__':
    pc = PControl(kp=7.6, base_speed=50)
    err = 2
    val = pc.get_adjust_value(err)
    print(val)