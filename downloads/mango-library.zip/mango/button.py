from machine import Pin
import time
 
    
class Button():
    PULL_DOWN = Pin.PULL_DOWN
    PULL_UP = Pin.PULL_UP
    EVENT_DOWN = 0
    EVENT_UP = 1       
    
    def __init__(self, button_pin='BTN', pull_mode=Pin.PULL_UP):        
        self.pull_mode = pull_mode
        self.pin = Pin(button_pin, Pin.IN, self.pull_mode)
        self.callback = []
        self.event = None
        self.last_flag = 0
        self.rising_debounce_time = 0
        self.falling_debounce_time = 0
        self.button_on = 0 if pull_mode is Pin.PULL_UP else 1
        self.button_up = 1 if pull_mode is Pin.PULL_UP else 0
        self.is_irq_mode = False
                    
    @property
    def value(self):
        return self.pin.value()
    
    @property
    def is_button_on(self):
        if self.pin.value() is self.button_on:
            return True
        else:
            return False
        
    @property
    def is_button_up(self):
        if self.pin.value() is self.button_up:
            return True
        else:
            return False
        
    def irq_mode(self, mode=True):
        self.is_irq_mode = mode
        if mode:
            self.pin.irq(handler=self.press_callback, trigger=Pin.IRQ_RISING|Pin.IRQ_FALLING)
        else:
            self.pin.irq(handler=None)
        
    def open_irq(self):
        self.irq_mode(True)    
    def irq_open(self):
        self.irq_mode(True)
        
    def press_callback(self, pin):
        flag = pin.irq().flags()        
        if flag is 8 and (time.ticks_ms()-self.rising_debounce_time) > 300:
            if self.pull_mode == Pin.PULL_DOWN:
                self._callback(self.EVENT_DOWN)
            else:
                self._callback(self.EVENT_UP)
            self.rising_debounce_time = time.ticks_ms()
        if flag is 4 and (time.ticks_ms()-self.falling_debounce_time) > 300:
            if self.pull_mode == Pin.PULL_DOWN:
                self._callback(self.EVENT_UP)
            else:
                self._callback(self.EVENT_DOWN)
            self.falling_debounce_time = time.ticks_ms()
                         
    def _callback(self, event):
        for f in self.callback:
            f(event)
        
    def close_irq(self):
        self.irq_mode(False)        
    def irq_close(self):
        self.irq_mode(False)
        


if __name__ == '__main__':
    import board
    
    def demo(event):
        event_name = "DOWN" if event is Button.EVENT_DOWN else "UP"
        print(event_name)
     
    # for X3
    btn = Button(button_pin=3, pull_mode=Button.PULL_UP)    
    btn.callback.append(demo)
    btn.irq_open()
    
    # for X2
    #btn = Button(button_pin=4, pull_mode=Pin.PULL_DOWN)
    while True:
        #print(btn.value)
        #print(btn.is_button_on)
        time.sleep(0.1)
