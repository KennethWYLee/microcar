from machine import Pin, I2C
from mango.oled import Writer, GFX, SSD1306_I2C, CubicWriter
from mango.oled.fonts import ubuntu_mono_12, ubuntu_mono_15, ubuntu_mono_20
import board
import time


class OLED():
    
    def __init__(self, i2c=None, width=128, height=64):
        self.i2c = i2c
        if self.i2c == None:
            self.i2c = I2C(1, scl="I2C_SCL", sda="I2C_SDA")
        self.width = width
        self.height = height
        self.oled = SSD1306_I2C(self.width, self.height, self.i2c)
        self.gfx = GFX(self.width, self.height, self.oled.pixel)
        self.write12 = Writer(self.oled, ubuntu_mono_12)
        self.write15 = Writer(self.oled, ubuntu_mono_15)
        self.write20 = Writer(self.oled, ubuntu_mono_20)
        self.cwriter = CubicWriter(self.oled)
        
    def pixel(self, x, y, color=1):
        self.oled.pixel(x, y, color)
        
    def line(self, x1, y1, x2, y2, color=1):
        self.gfx.line(x1, y1, x2, y2, color)
        
    def rect(self, x, y, width, height, color=1):
        self.gfx.rect(x, y, width, height, color)
        
    def circle(self, x, y, radius, color=1):
        self.gfx.circle(x, y, radius, color)
        
    def fill_rect(self, x, y, width, height, color=1):
        self.gfx.fill_rect(x, y, width, height, color)
        
    def text12(self, text, x, y, color=1):
        bgcolor = 1
        if color == 1:
            bgcolor = 0
        self.write12.text(text, x, y, color=color)
        
    def text15(self, text, x, y, color=1):
        bgcolor = 1
        if color == 1:
            bgcolor = 0
        self.write15.text(text, x, y, color=color)
        
    def text20(self, text, x, y, color=1):
        bgcolor = 1
        if color == 1:
            bgcolor = 0
        self.write20.text(text, x, y, color=color)
        
    def set_chinese_words(self, words):
        self.cwriter.set_words(words)
    
    def chinese_text(self, string, x, y, invert=False):
        self.cwriter.text(string, x, y, invert=False)
        
    def chinese_menu(self, string, x, y, selected=False):
        self.cwriter.menu_text(string, x, y, selected)
        
    def invert(self, invert):
        self.oled.invert(invert)
        
    def show(self):
        self.oled.show()
        
    def clear(self):
        self.oled.fill(0)
        self.oled.show()
        
    def draw_image(self, image_buf, x, y):
        self.oled.draw_image(image_buf, x, y)
        
    def show_image_data(self, array_bitmap, invert=0):
        self.oled.show_image_data(array_bitmap, invert)
        
    def fill(self, color=1):
        self.oled.fill(color)
        self.oled.show()
        
    def power_on(self):
        self.oled.poweron()
        
    def power_off(self):
        self.oled.poweroff()
        
        
   
WIDTH = 128
HEIGHT = 64

def init(i2c_num=0, scl_pin=21, sda_pin=20, width=WIDTH, height=HEIGHT):
    scl = Pin(scl_pin) 
    sda = Pin(sda_pin)
    i2c = I2C(i2c_num, scl=scl, sda=sda)    
    try:
        return OLED(i2c, WIDTH, HEIGHT)
    except Exception as e:
        print(e)
        return None

def demo(oled):
    oled.clear()
    oled.text15("MangoBlock", 0, 0, 0)
    oled.text15("uMakerBot-PicoX2", 0, 15, 1)
    oled.line(0, 32, 127, 32, 1)    
    oled.text20("1234567890", 0, 35)
    oled.text15("Ubuntu Mono font", 0, 52)
    oled.show()
    time.sleep(5)
    oled.clear()
    oled.text15("MangoBlock IDE", 0, 0)
    oled.rect(0, 15, 128, 15, 1)
    oled.text15("micropython-oled", 0, 15, color=0)
    for i in range(10):
        if i % 2:
            color, bgcolor = 1, 0
        else:
            color, bgcolor = 0, 1

        oled.text20("{}".format(i), i * 10, 35, color=color)

    oled.rect(0, 35, 1 + (i + 1) * 10, 20, 1)
    oled.show()
    time.sleep(2)
    oled.clear()
    
def demo_drawing(oled):
    oled.clear()
    oled.pixel(10, 10, 1)
    oled.pixel(11, 11, 1)
    oled.pixel(12, 13, 1)
    oled.pixel(13, 15, 1)
    oled.circle(40, 20, 20, 1)
    oled.show()
 
def test(oled):
    oled.clear()
    for i in range(64):
        oled.line(0, i, 128, i, 1)
        oled.show()
        time.sleep(0.2)
    for i in range(64):
        oled.line(0, i, 128, i, 0)
        oled.show()
        time.sleep(0.2)
    

    
    
if __name__ == '__main__':
    #demo()    
    from mango import bus
    from mango.icons import mango_logo as icon
    
    oled = OLED(bus.i2c)
    oled.power_on()
    #test(oled)
    demo(oled)
    oled.show_image_data(icon.bitmap_data, 1)    
    time.sleep(3)
    oled.clear()
    oled.power_off()
    
    
