from machine import Pin, Timer


class Encoder:
    '''
    encoder freq = motor freq
    '''
    def __init__(self, pin_a, pin_b, ppr=13, freq=100):
        self.hall_a = Pin(pin_a, Pin.IN)
        self.hall_b = Pin(pin_b, Pin.IN)        
        self.ppr = ppr
        self.freq = freq
        self.pulse_count = 0              
        self.hall_a.irq(handler=None)
        self.hall_timer = Timer(-1)
        self.callback = None
                
    def _callback(self, timer):
        if self.callback:
            self.callback(self.pulse_count)
        
    def _read_quadrature(self, pin):
        # A相下降觸發, 正轉: A=0, B=1, 反轉: A=0, B=0
        if self.hall_b.value() is 1:
            self.pulse_count = self.pulse_count + 1
        else:
            self.pulse_count = self.pulse_count - 1            
                
    def start(self):
        self.reset()
        self.hall_a.irq(handler=self._read_quadrature, trigger=Pin.IRQ_FALLING)
        self.hall_timer.init(freq=self.freq, mode=Timer.PERIODIC, callback=self._callback)
        
    def stop(self):
        self.hall_timer.deinit()
        self.hall_a.irq(handler=None)
        self.reset()
        
    def reset(self):
        self.pulse_count = 0
        
        
if __name__ == '__main__':    
    from mango.button import Button
    from mango.motor import DCMotor
    import time
    import board
    
    encoder1 = Encoder(board.EC1[1], board.EC1[0])
    encoder2 = Encoder(board.EC2[0], board.EC2[1])
   
    btn = Button()
        
    def motor1_count(count):
        print("motor 1 count = {}".format(count))
        
    def motor2_count(count):
        print("motor 2 count = {}".format(count))
        
    def stop_all(event):
        if btn.is_button_on:
            encoder1.stop()
            encoder2.stop()
            btn.close_irq()
            print("--- stop ---")
        
    btn.callback.append(stop_all)
    btn.open_irq()
     
    encoder1.callback = motor1_count
    encoder2.callback = motor2_count
    encoder1.start()
    encoder2.start()
    
    time.sleep(3)
           
    encoder1.stop()
    encoder2.stop()