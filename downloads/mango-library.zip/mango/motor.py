from machine import Pin, PWM
from mango.encoder import Encoder
from mango import utils
import time

FAST_DECAY = 0
SLOW_DECAY = 1

PWM_FREQ = 100

MOTOR_TT = 1
MOTOR_TT_ENCODER = 2
MOTOR_310 = 3
MOTOR_310_ENCODER = 4

class DCMotor:
    '''
    This class is for DRV8833 motor driver
    '''
    def __init__(self, positive_pin, negative_pin, pwm_freq=PWM_FREQ):
        positive_pwm = PWM(Pin(positive_pin))
        negative_pwm = PWM(Pin(negative_pin))
        positive_pwm.freq(pwm_freq)
        negative_pwm.freq(pwm_freq)
        self._positive = positive_pwm
        self._negative = negative_pwm
        self._throttle = None
        self._decay_mode = FAST_DECAY
        self._speed = 100
        self._state = 0 #0.stop, 1.running
        
    @property
    def throttle(self):
        """
        Motor speed, ranging from -1.0 (full speed reverse) to 1.0 (full speed forward),
        or None (controller off).
        If None, both PWMs are turned full off. If 0.0, both PWMs are turned full on.
        """
        return self._throttle

    @throttle.setter
    def throttle(self, value):
        if value is not None and (value > 1.0 or value < -1.0):
            raise ValueError("Throttle must be None or between -1.0 and +1.0")
        self._throttle = value
        if value is None:  # Turn off motor controller (high-Z)
            self._positive.duty_u16(0)
            self._negative.duty_u16(0)
        elif value == 0:  # Brake motor (low-Z)
            self._positive.duty_u16(0xFFFF)
            self._negative.duty_u16(0xFFFF)
        else:
            duty_cycle = int(0xFFFF * abs(value))
            if self._decay_mode == SLOW_DECAY:  # Slow Decay (Braking) Mode
                if value < 0:
                    self._positive.duty_u16(0xFFFF - duty_cycle)
                    self._negative.duty_u16(0xFFFF)
                else:
                    self._positive.duty_u16(0xFFFF)
                    self._negative.duty_u16(0xFFFF - duty_cycle)
            else:  # Default Fast Decay (Coasting) Mode
                if value < 0:
                    self._positive.duty_u16(0)
                    self._negative.duty_u16(duty_cycle)
                else:
                    self._positive.duty_u16(duty_cycle)
                    self._negative.duty_u16(0)

    @property
    def decay_mode(self):
        """
        Motor controller recirculation current decay mode. A value of 'motor.FAST_DECAY'
        sets the motor controller to the default fast recirculation current decay mode
        (coasting); 'motor.SLOW_DECAY' sets slow decay (braking) mode.
        """
        return self._decay_mode

    @decay_mode.setter
    def decay_mode(self, mode=FAST_DECAY):
        if mode in (FAST_DECAY, SLOW_DECAY):
            self._decay_mode = mode
        else:
            raise ValueError(
                "Decay mode value must be either motor.FAST_DECAY or motor.SLOW_DECAY"
            )

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        self.throttle = None
        
    @property
    def motor_type(self):
        return MOTOR_TT
    
    def set_positive_pin(self, pin):
        positive_pwm = PWM(Pin(pin))        
        positive_pwm.freq(PWM_FREQ)        
        self._positive = positive_pwm        
        
    def set_negative_pin(self, pin):        
        negative_pwm = PWM(Pin(pin))        
        negative_pwm.freq(PWM_FREQ)        
        self._negative = negative_pwm
        
    def set_pin(self, pin1, pin2):
        self.set_positive_pin(pin1)
        self.set_negative_pin(pin2)
             
    def speed_valify(self, value):
        is_forward = True
        if value < 0:
            is_forward = False
        if abs(value) < 0:
            value = 0
        if abs(value) > 100:
            value = 100
        self._speed = value if is_forward else -value

    def run(self, speed):
        self.speed_valify(speed)
        spd = utils.map(abs(self._speed), 0, 100, 0, 1)
        if speed < 0:
            self.throttle = -spd
        else:
            self.throttle = spd
        if self._state == 0:            
            self._state = 1
            
    def speed(self, speed):
        self.run(speed)
            
    @property
    def state(self):
        return self._state
    
    def stop(self):
        self.decay_mode = SLOW_DECAY
        self.throttle = 0        
        self._state = 0
        
    def brakes(self):
        self.decay_mode = FAST_DECAY
        self.throttle = 0        
        self._state = 0

    def release(self):
        self.throttle = None        
        
    def reset(self):        
        self._state = 0
        


class Motor:
    '''
    This class is for normal DC motor with using PWM control.
    '''
    def __init__(self, a_pin=16, b_pin=17):
        self.freq = 50
        self.pin_a = a_pin
        self.pin_b = b_pin
        self.pwm_a = PWM(Pin(a_pin, Pin.OUT))
        self.pwm_b = PWM(Pin(b_pin, Pin.OUT))
        self.pwm_a.freq(self.freq)
        self.pwm_b.freq(self.freq)
        
    def map_int(self, x, in_min=0, in_max=100, out_min=0, out_max=65535):
        val = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min    
        return int(val)
    
    def release(self):
        self.pwm_a.deinit()
        self.pwm_b.deinit()
        
    def reset(self):
        self.pwm_a = PWM(Pin(self.pin_a, Pin.OUT))
        self.pwm_b = PWM(Pin(self.pin_b, Pin.OUT))
        self.pwm_a.freq(self.freq)
        self.pwm_b.freq(self.freq)
    
    def run(self, a_duty, b_duty):
        self.pwm_a.duty_u16(a_duty)
        self.pwm_b.duty_u16(b_duty)

    # duty_per = -100 ~ 0 ~ 100
    def speed(self, duty_per=20):
        per = abs(duty_per)
        duty = self.map_int(per)
        #print(duty)
        if duty_per > 0:
            # CW
            self.run(duty, 0)
        elif duty_per < 0:
            # CCW
            self.run(0, duty)
        else:
            self.run(0, 0)
            
    def stop(self):
        self.run(0, 0)
            
    def brakes(self):
        self.run(0xFFFF, 0xFFFF)

'''
ULN2003 Stepper motor driver
Stepper Mode: 28BYJ-48
The 28BYJ-48 Stepper Motor has a stride angle of 5.625°/64 in half-step mode.
A step angle of 5.625º—so it needs 360º/5.625º = 64 steps in half-step mode.
In full-step mode: 64/2 = 32 steps to complete one rotation.
gear ratio = 64:1
Total steps per revolution = 2048 steps
Step angle = 0.18º/step
'''
class StepMotor:
    # waiting time
    stepms = 10
    # Do be defined by subclasses
    maxpos = 0
    states = []

    def __init__(self, p1, p2, p3, p4, stepms=None):
        self.pins = [p1, p2, p3, p4]
        if stepms is not None:
            self.stepms = stepms
        self._state = 0
        self._pos = 0

    def __repr__(self):
        return '<{} @ {}>'.format(
            self.__class__.__name__,
            self.pos,
        )

    @property
    def pos(self):
        return self._pos

    @classmethod
    def frompins(cls, *pins, **kwargs):
        return cls(*[Pin(pin, Pin.OUT) for pin in pins], **kwargs)

    def reset(self):
        self._pos = 0

    def _step(self, dir):
        state = self.states[self._state]
        for i, val in enumerate(state):
            self.pins[i].value(val)

        self._state = (self._state + dir) % len(self.states)
        self._pos = (self._pos + dir) % self.maxpos

    def step(self, steps):
        dir = 1 if steps >= 0 else -1
        steps = abs(steps)
        for _ in range(steps):
            t_start = time.ticks_ms()
            self._step(dir)
            t_end = time.ticks_ms()
            t_delta = time.ticks_diff(t_end, t_start)
            time.sleep_ms(self.stepms - t_delta)

    def step_until(self, target, dir=None):
        if target < 0 or target > self.maxpos:
            raise ValueError(target)

        if dir is None:
            dir = 1 if target > self._pos else -1
            if abs(target - self._pos) > self.maxpos/2:
                dir = -dir

        while True:
            if self._pos == target:
                break
            self.step(dir)

    def step_until_angle(self, angle, dir=None):
        if angle < 0 or angle > 360:
            raise ValueError(angle)
        target = int(angle / 360 * self.maxpos)
        self.step_until(target, dir=dir)
        
    def step_degrees(self, degrees):
        if degrees < 0 or degrees > 360:
            raise ValueError("Degrees should be between 0 and 360")

        steps_to_take = int(degrees / 360 * self.maxpos)
        #self.zero()  # Ignore the current position, start from zero
        self.step(steps_to_take)


class FullStepMotor(StepMotor):
    stepms = 5
    maxpos = 2048
    states = [
        [1, 1, 0, 0],
        [0, 1, 1, 0],
        [0, 0, 1, 1],
        [1, 0, 0, 1],
    ]


class HalfStepMotor(StepMotor):
    stepms = 3
    maxpos = 4096
    states = [
        [1, 0, 0, 0],
        [1, 1, 0, 0],
        [0, 1, 0, 0],
        [0, 1, 1, 0],
        [0, 0, 1, 0],
        [0, 0, 1, 1],
        [0, 0, 0, 1],
        [1, 0, 0, 1],
    ]


class NEMA17:
    '''
    42步進電機控制, 使用 DRV8825 驅動器
    '''
    def __init__(self, step_pin, dir_pin):
        self.step_pin = Pin(step_pin, Pin.OUT)
        self.dir_pin = Pin(dir_pin, Pin.OUT)
        self.position = 0
 
    def set_speed(self, speed):
        self.delay = 1 / abs(speed)  # delay in seconds
 
    def set_direction(self, direction):
        self.dir_pin.value(direction)
 
    def move_to(self, position):
        self.set_direction(1 if position > self.position else 0)
        while self.position != position:
            self.step_pin.value(1)
            time.sleep(self.delay)
            self.step_pin.value(0)
            self.position += 1 if position > self.position else -1
            
           

if __name__ == '__main__':
    import board
    
    def test_dc_motor():
        #m1 = Motor(8, 9)
        #m2 = Motor(11, 10)
        m1 = DCMotor(12, 13)
        m2 = DCMotor(11, 10)
        
        m1.speed(15)
        m2.speed(15)    
        time.sleep(5)
        m1.brakes()
        m2.brakes()
    
    def test_stepper():
        stepper_motor = HalfStepMotor.frompins(7,8,9,18)
        stepper_motor.reset()
        try:
            while True:
                #Move 500 steps in clockwise direction
                stepper_motor.step(500)
                time.sleep(0.5) # stop for a while
                
                # Move 500 steps in counterclockwise direction
                stepper_motor.step(-500)
                time.sleep(0.5) # stop for a while
                
                # Go to a specific position (in steps)
                stepper_motor.step_until(2000)
                time.sleep(0.5) # stop for a while
                
                # Force a direction using the dir paramter
                stepper_motor.step_until(2000, dir=-1)
                time.sleep(0.5) # stop for a while        
                
                # Go to a specific position (angle, maximum is 359, otherwise it will spin indefinetely)
                stepper_motor.step_until_angle(359)
                time.sleep(0.5) # stop for a while
            
        except KeyboardInterrupt:
            print('Keyboard interrupt')
    
    def test_stepper42():
        step_pin = 17
        dir_pin = 16
        stepper = NEMA17(dir_pin, step_pin)
        while True:
            stepper.move(600, 2000, 5)  # 2 revolutions forward
            utime.sleep(1)
            stepper.move(-600, 2000, 5)  # 2 revolutions backward
            utime.sleep(1)
    
    # exec    
    test_stepper()