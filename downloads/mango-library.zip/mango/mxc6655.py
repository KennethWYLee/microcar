from machine import I2C
from time import sleep_us
from mango import I2CBus


class MXC6655(I2CBus):
    TWO_G = 0
    REG_X_AXIS = 0x03
    REG_Y_AXIS = 0x05
    REG_Z_AXIS = 0x07
    REG_TMP_OUT  = 0x09
    REG_WHO_AM_I = 0x0F
    
    def __init__(self):
        super().__init__(1)
        self.addr = 0x15
        self.shake_addr = 0x00
        self.id_addr = self.REG_WHO_AM_I
        self.offset = [0, 0, 0]
        
    def begin(self):
        # shake & clear reg.
        self.shake()
        sleep_us(100)
        # read who am i
        val = self.get_device_id()
        error = 0
        if val == b'\x05':
            print('An MXC6655XA device was found.')
            self.write_byte(0x0D, 0x00)
        else:
            print('The MXC6655XA device was not found.')
            error = -1
        return error

    # Read 2 bytes data then shift out empty bits
    # Divide by 12 bit resolution, multiply by FSR, add offset
    def get_accel(self):        
        xAccl = self.read_word(self.REG_X_AXIS)
        xAccl = xAccl >> 4 # shift out empty bits
        xAccl = (xAccl/2048.0)*2 + self.offset[0]
        yAccl = self.read_word(self.REG_Y_AXIS)
        yAccl = yAccl >> 4
        yAccl = (yAccl/2048.0)*2 + self.offset[1]
        zAccl = self.read_word(self.REG_Z_AXIS)
        zAccl = zAccl >> 4
        zAccl = (zAccl/2048.0)*2 + self.offset[2]
        return xAccl, yAccl, zAccl
    
    def get_temp(self):
        val = self.read_byte(self.REG_TMP_OUT)
        int_val = self.to_int(val)
        val = (float(int_val) * 0.586) + 25.0
        return val
    
    def to_int(self, val):
        int_val = int.from_bytes(val, "little")
        return int_val


if __name__ == "__main__":    
    import time
    
    
    accl = MXC6655()
    accl.begin()
    while True:    
        xAccl, yAccl, zAccl = accl.get_accel()     
        print(f'X-Axis={xAccl}, Y-Axis={yAccl}, Z-Axis={zAccl}')
    
        tmp = accl.get_temp()
        print(f'temprature = {tmp}')
        time.sleep(0.1)
    
