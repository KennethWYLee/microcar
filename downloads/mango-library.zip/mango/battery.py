# 電池電量OLED顯示
# date: 2023/12/30
import mangoblock
import board
import time
from mango import bus
from mango import OLED
from mango.voltage_sensor import VoltageSensor
from mango.battery_indicator import BatteryIndicator


oled = OLED(bus.i2c)
sensor = VoltageSensor(adc_pin=27, vcc=5, bat_voltage=8.4, adjust_vol=0.02)
bat = BatteryIndicator(oled, sensor)

bat.show()