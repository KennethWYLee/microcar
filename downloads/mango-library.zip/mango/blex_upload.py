# mangoblock boot
import mangoblock
import os
from mango import utils
from mango import BlexMgr
 
 
def upload_begin(filename):
    BlexMgr.file_name = filename
    if BlexMgr.has_sdcard:                        
        BlexMgr.file_name = f'/sd/{filename}'
    if utils.file_exists(BlexMgr.file_name):
        utils.file_remove(BlexMgr.file_name)                            
        BlexMgr.f = open(BlexMgr.file_name, 'w', encoding='utf-8')                    
        BlexMgr.f.close()
        
def upload_data(scripts):
    if BlexMgr.file_name != '':
        BlexMgr.f = open(BlexMgr.file_name, 'a')
        BlexMgr.f.write(scripts)
        BlexMgr.f.close()
        
def upload_end(mode=0):
    if BlexMgr.f != None:
        BlexMgr.f.close()
        BlexMgr.f = None
    if mode == 1:
        BlexMgr.f = open(BlexMgr.file_name)
        exec(BlexMgr.f.read())
        BlexMgr.f.close()
        BlexMgr.f = None
    BlexMgr.file_name = ''
    

# ----------------------------     
if utils.file_exists("/sd"):
    BlexMgr.has_sdcard = True
