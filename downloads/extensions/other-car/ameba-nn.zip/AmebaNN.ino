#include <WiFi.h>
#include <Wire.h>
#include "SPI.h"
#include "StreamIO.h"
#include "VideoStream.h"
#include "AmebaFatFS.h"
#include "NNObjectDetection.h"
#include "VideoStreamOverlay.h"
#include "ObjectClassList.h"

// Mango AI
#include "AmebaPin.h"
#include "AmebaTFT_ST7789.h"
#include "AmebaUART.h"
#include "AmebaWebCam.h"
#include "MangoLogo.h"

#define TFT_RESET       17
#define TFT_DC          29
#define TFT_CS          SPI1_SS  //PIN=D3
#define TFT_BL          8
#define TFT_WIDTH       320
#define TFT_HEIGHT      240
#define ST7789_SPI_FREQUENCY 20000000
// UART
#define UART_TIMER_ID 0
// camera
#define CHANNEL_IMG 0
#define CHANNEL_NN 3
// Lower resolution for NN processing
#define NN_WIDTH  576
#define NN_HEIGHT 320

VideoSetting configCam(1024, 576, CAM_FPS, VIDEO_JPEG, 1);
VideoSetting configNN(NN_WIDTH, NN_HEIGHT, 10, VIDEO_RGB, 0);

StreamIO videoStreamerCam(1, 1);
StreamIO videoStreamerNN(1, 1);

NNObjectDetection ObjDet;

// wifi settings
char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD"; 
char ap_ssid[] = "MangoAP";
char ap_pass[] = "12345678";
char ap_channel[] = "1";
int ssid_status = 0;
int status = WL_IDLE_STATUS;

IPAddress ip;
bool gotIP = false;
bool isWiFiStart = false;
bool isServerStart = false;

AmebaST7789 tft = AmebaST7789(TFT_CS, TFT_DC, TFT_RESET, TFT_BL);
AmebaWebCam webcam(1024, 1, "webserver", CHANNEL_IMG);


// for UART
String uartString = "";
bool stringComplete = false;
int incomingByte = 0;

// LED
int button = PUSH_BTN;
int led = LED_BUILTIN;
int ledState = 1;


void button_handler(uint32_t id, uint32_t event)
{
    if (ledState == 0) {
        // turn on LED
        ledState = 1;
        digitalWrite(led, ledState);
    } else {
        // turn off LED
        ledState = 0;
        digitalWrite(led, ledState);
    }
}

// TFT
int tftState = 1;
void sw3_handler(uint32_t id, uint32_t event)
{
    if (tftState == 0) {
        // turn on TFT
        tftState = 1;
        tft.setLightOn(true);
        drawMangoLogo();
    } else {
        // turn off TFT
        tftState = 0;
        tft.setLightOn(false);
    }
    delay(10);
}

// ----------------------- user defined function ------------------------------------------
String split(String data, char separator, int index) {
    int found = 0;
    int strIndex[] = { 0, -1 };
    int maxIndex = data.length() - 1;
    for (int i = 0; i <= maxIndex && found <= index; i++) {
        if (data.charAt(i) == separator || i == maxIndex) {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i+1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

String IPtoString(IPAddress& ip) { // IP v4 only
  String ips;
  ips.reserve(16);
  ips = ip[0];  ips += '.';
  ips += ip[1]; ips += '.';
  ips += ip[2]; ips += '.';
  ips += ip[3];
  return ips;
}

// UART
void uartHandler() {
  while (MySerial.available() > 0) {
    // get the new byte:
    incomingByte  = MySerial.read();    
    char inChar = (char)incomingByte;   
    if (inChar == '\n') {
      MySerial.println("Rv: " + uartString);
      String cmd = split(uartString, '|', 0);
      if(cmd == "ASK") {
        String task = split(uartString, '|', 1);
        tft.setCursor(20, 200);
        tft.println(task);
        if(task == "IP") {
          MySerial.println("Task=IP"); 
          ip = WiFi.localIP();     
          String sIPAddress = IPtoString(ip);
          MySerial.println("IP: " + sIPAddress);
        }
      }
      else if(cmd == "TFT") {
        String task = split(uartString, '|', 1);
        if(task == "ON") {
          tft.setLightOn(true);
          drawMangoLogo();
        }
        else if(task == "OFF") {
          tft.setLightOn(false);
        }        
        tft.setCursor(20, 200);
        tft.println(task);
      }
      
      uartString = "";
      //MySerial.println("ok");
    }
    else {
      uartString += inChar; 
    }
  }    
}

// main menu
void drawMainMenu() {
  //
}

// init TFT LCD
void drawMangoLogo() {
  tft.clr();
  tft.fillScreen(ST7789_BLACK);
  int x = TFT_WIDTH - 240;
  if(x > 0) {
    x = x / 2;
  }
  tft.drawBitmap(x, 0, 240, 240, MangoLogo);
}

// OSD process
void ObjectDetectPostProcess(std::vector<ObjectDetectionResult> results)
{
  uint16_t im_h = configCam.height();
  uint16_t im_w = configCam.width();

  printf("Total number of objects detected = %d\r\n", ObjDet.getResultCount());
  OSD.createBitmap(CHANNEL_IMG);
  if (ObjDet.getResultCount() > 0) {
    for (int i = 0; i < ObjDet.getResultCount(); i++) {
      int obj_type = results[i].type();
      if (itemList[obj_type].filter) {    // check if item should be ignored
        ObjectDetectionResult item = results[i];
        // Result coordinates are floats ranging from 0.00 to 1.00
        // Multiply with RTSP resolution to get coordinates in pixels
        int xmin = (int)(item.xMin() * im_w);
        int xmax = (int)(item.xMax() * im_w);
        int ymin = (int)(item.yMin() * im_h);
        int ymax = (int)(item.yMax() * im_h);
        // Draw boundary box
        printf("Item %d %s:\t%d %d %d %d\n\r", i, itemList[obj_type].objectName, xmin, xmax, ymin, ymax);
        OSD.drawRect(CHANNEL_IMG, xmin, ymin, xmax, ymax, 3, OSD_COLOR_WHITE);
        // Print identification text
        char text_str[20];
        snprintf(text_str, sizeof(text_str), "%s %d", itemList[obj_type].objectName, item.score());
        OSD.drawText(CHANNEL_IMG, xmin, ymin - OSD.getTextHeight(CHANNEL_IMG), text_str, OSD_COLOR_CYAN);
        //
        char respText[20];
        snprintf(respText, sizeof(respText), "%s %d", itemList[obj_type].objectName, item.score());
        MySerial.println(respText);        
        // TFT display  
        char dispText[20];
        snprintf(dispText, sizeof(respText), "object: %s", itemList[obj_type].objectName);
        tft.clearLineBackground(160, 2);
        tft.drawText(20, 160, dispText, ST7789_WHITE, 2);   
      }
    }
  }
  OSD.update(CHANNEL_IMG);
}


void setup()
{ 
  // Monitor
  Serial.begin(115200);  
  // LED & Button
  pinMode(led, OUTPUT);
  digitalWrite(led, ledState);
  pinMode(button, INPUT_IRQ_RISE);
  digitalSetIrqHandler(button, button_handler);  
  // SW3
  pinMode(USR_PIN_SW3, INPUT_IRQ_RISE);
  digitalSetIrqHandler(USR_PIN_SW3, sw3_handler);  
  // TFT
  SPI1.setDefaultFrequency(ST7789_SPI_FREQUENCY);
  tft.begin(TFT_WIDTH, TFT_HEIGHT);
  tft.setLightOn(true);
  drawMangoLogo();
  // WiFi
  // 轉換為 char 陣列
  String fullSSID = genSSID();
  fullSSID.toCharArray(ap_ssid, sizeof(fullSSID)+1);
  while (status != WL_CONNECTED)  {
    status = WiFi.apbegin(ap_ssid, ap_pass, ap_channel, ssid_status);
  }  
  delay(10000);
  Serial.println("AP mode already started");
  //printWifiData();
  //printCurrentNet();
  // TFT display
  tft.clr();  
  tft.fillScreen(ST7789_RED);
  tft.setBackground(ST7789_RED);  
  tft.drawText(20, 30, "Mango AI", ST7789_GREEN, 3);       
  // UART
  //tft.setForeground(ST7789_WHITE);
  //tft.setCursor(20,80);
  //tft.setFontSize(2);
  //tft.println("Wait UART...");
  MySerial.begin(115200);
  while (!MySerial) yield();
  MySerial.setCallback(uartHandler);
  //tft.setCursor(20,80);
  //tft.setFontSize(2);
  //tft.println("UART: ready    "); 
  // camera
  Camera.configVideoChannel(CHANNEL_IMG, configCam);  
  Camera.configVideoChannel(CHANNEL_NN, configNN);
  Camera.videoInit();
  
  ObjDet.configVideo(configNN);
  ObjDet.setResultCallback(ObjectDetectPostProcess);
  ObjDet.modelSelect(OBJECT_DETECTION, DEFAULT_YOLOV7TINY, NA_MODEL, NA_MODEL);
  ObjDet.begin();

  videoStreamerCam.registerInput(Camera.getStream(CHANNEL_IMG));
  if (videoStreamerCam.begin() != 0)
  {
    Serial.println("StreamIO link start failed");
  }

  videoStreamerNN.registerInput(Camera.getStream(CHANNEL_NN));
  videoStreamerNN.setStackSize();
  videoStreamerNN.setTaskPriority();
  videoStreamerNN.registerOutput(ObjDet);
  if (videoStreamerNN.begin() != 0) {
    Serial.println("StreamIO link start failed");
  }
 
  // start video channel for camera
  Camera.channelBegin(CHANNEL_IMG); 
  //tft.setCursor(20,100);
  //tft.println("Camera: ready    ");  
  // Start video channel for NN
  Camera.channelBegin(CHANNEL_NN);

  // Start OSD drawing on video channel
  OSD.configVideo(CHANNEL_IMG, configCam);
  OSD.begin();
  
  // web cam
  webcam.start(); 
  //
  printWifiData();
}

void loop()
{

}

void printWifiData()
{
  // ssid
  Serial.print("SSID: ");
  Serial.println(WiFi.SSID());
  tft.setForeground(ST7789_WHITE);
  tft.setFontSize(2);
  tft.setCursor(20, 100);
  tft.print("SSID: ");
  tft.println(WiFi.SSID());
  //tft.drawText(20, 100, WiFi.SSID(), ST7789_GREEN, 3);

  // print your WiFi IP address:  
  IPAddress ip = WiFi.localIP();
  Serial.print("IP Address: ");
  Serial.println(ip);
  //char ipBuffer[16]; // 足夠存放 "255.255.255.255"
  //snprintf(ipBuffer, sizeof(ipBuffer), "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
  String ipString = ipToString(ip);
  tft.drawText(20, 120, "IP: "+ipString, ST7789_WHITE, 2);

  // print your subnet mask:
  IPAddress subnet = WiFi.subnetMask();
  Serial.print("NetMask: ");
  Serial.println(subnet);

  // print your gateway address:
  IPAddress gateway = WiFi.gatewayIP();
  Serial.print("Gateway: ");
  Serial.println(gateway);
  Serial.println();
}

void printCurrentNet()
{
    // print the SSID of the AP:
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());

    // print the MAC address of AP:
    byte bssid[6];
    WiFi.BSSID(bssid);
    Serial.print("BSSID: ");
    Serial.print(bssid[0], HEX);
    Serial.print(":");
    Serial.print(bssid[1], HEX);
    Serial.print(":");
    Serial.print(bssid[2], HEX);
    Serial.print(":");
    Serial.print(bssid[3], HEX);
    Serial.print(":");
    Serial.print(bssid[4], HEX);
    Serial.print(":");
    Serial.println(bssid[5], HEX);

    // print the encryption type:
    byte encryption = WiFi.encryptionType();
    Serial.print("Encryption Type:");
    Serial.println(encryption, HEX);
    Serial.println();
}

String ipToString(IPAddress ip) {
  String ipString = String(ip[0]) + "." + 
                  String(ip[1]) + "." + 
                  String(ip[2]) + "." + 
                  String(ip[3]);
  return ipString;
}

String genSSID() {
  byte bssid[6]; 
  int retry = 0;
    
  // 重試機制
  while (retry < 5) {
    WiFi.BSSID(bssid);        
    // 如果 MAC 有效
    if (bssid[0] != 0 || bssid[1] != 0 || bssid[2] != 0) {
        char last4[5];
        snprintf(last4, sizeof(last4), "%02X%02X", bssid[4], bssid[5]);
        return "MangoAP_" + String(last4);
    } 
    // 否則使用隨機數
    else {
        uint16_t randomNum = random(1000, 10000);
        return "MangoAP_" + String(randomNum);
    }
  }
  return "MangoAP";
}
