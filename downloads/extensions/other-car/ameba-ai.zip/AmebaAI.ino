#include <WiFi.h>
#include <Wire.h>
#include "SPI.h"
#include "BLEDevice.h"
#include "BLEWifiConfigService.h"
#include "StreamIO.h"
#include "VideoStream.h"
#include "AmebaPin.h"
#include "AmebaST7789.h"
#include "AmebaFatFS.h"
#include "NNObjectDetection.h"
#include "NNGestureDetection.h"
#include "VideoStreamOverlay.h"
#include "ObjectClassList.h"
#include "MangoLogo.h"

#define TFT_RESET       17
#define TFT_DC          29
#define TFT_CS          SPI1_SS  //PIN=D3
#define TFT_BL          8
#define TFT_WIDTH       320
#define TFT_HEIGHT      240
#define ST7789_SPI_FREQUENCY 20000000
// UART
#define UART_TIMER_ID 0
// camera
#define CHANNEL_IMG 0
#define CHANNEL_NN 3
// Lower resolution for NN processing
#define NN_WIDTH  576
#define NN_HEIGHT 320

// VideoSetting configCam(VIDEO_HD, CAM_FPS, VIDEO_JPEG, 1);
VideoSetting configCam(VIDEO_VGA, CAM_FPS, VIDEO_JPEG, 1);
//VideoSetting configCam(1024, 576, CAM_FPS, VIDEO_JPEG, 1);

// object detect
VideoSetting configNN(NN_WIDTH, NN_HEIGHT, 10, VIDEO_RGB, 0);
StreamIO videoStreamerNN(1, 1);
NNObjectDetection ObjDet;
// hand gesture detect
StreamIO videoStreamerRGBGD(1, 1);
NNGestureDetection gesturedetect;

// wifi settings
char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD"; 
int status = WL_IDLE_STATUS;
IPAddress ip;
bool gotIP = false;
bool isWiFiStart = false;
bool isServerStart = false;
bool isCameraStart = false;
int wifiTryTimes = 5;

WiFiServer server(80);

BLEWifiConfigService configService;

AmebaST7789 tft = AmebaST7789(TFT_CS, TFT_DC, TFT_RESET, TFT_BL);

// for UART

bool isAIStart = false;
String lastAITask = "0";

// for camera
uint32_t img_addr = 0;
uint32_t img_len = 0;
#define PART_BOUNDARY "123456789000000000000987654321"
char* STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
char* IMG_HEADER = "Content-Type: image/jpeg\r\nContent-Length: %lu\r\n\r\n";
//FreeRTOS
TaskHandle_t xHandleHttpTask = NULL;
TaskHandle_t xHandleSerialTask = NULL;

// define tasks
void TaskReadFromSerial(void *pvParameters); // Get commands
void TaskHttpRequest(void *param);

// LED
int button = PUSH_BTN;
int ledState = 1;

void button_handler(uint32_t id, uint32_t event)
{
    if (ledState == 0) {
        // turn on LED
        ledState = 1;
        digitalWrite(PIN_LED_BLUE, ledState);
    } else {
        // turn off LED
        ledState = 0;
        digitalWrite(PIN_LED_BLUE, ledState);
    }
}

// TFT
int tftState = 1;
void sw3_handler(uint32_t id, uint32_t event)
{
    if (tftState == 0) {
        // turn on TFT
        tftState = 1;
        tft.setLightOn(true);
        drawMangoLogo();
    } else {
        // turn off TFT
        tftState = 0;
        tft.setLightOn(false);
    }
    delay(10);
}

// ----------------------- user defined function ------------------------------------------
String split(String data, char separator, int index) {
    int found = 0;
    int strIndex[] = { 0, -1 };
    int maxIndex = data.length() - 1;
    for (int i = 0; i <= maxIndex && found <= index; i++) {
        if (data.charAt(i) == separator || i == maxIndex) {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i+1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

String IPtoString(IPAddress& ip) { // IP v4 only
  String ips;
  ips.reserve(16);
  ips = ip[0];  ips += '.';
  ips += ip[1]; ips += '.';
  ips += ip[2]; ips += '.';
  ips += ip[3];
  return ips;
}


// main menu
void drawMainMenu() {
  //
}

// TFT: show mango logo
void drawMangoLogo() {
  tft.clr();
  tft.fillScreen(ST7789_BLACK);
  tft.setBackground(ST7789_BLACK);
  int x = TFT_WIDTH - 240;
  if(x > 0) {
    x = x / 2;
  }
  tft.drawBitmap(x, 0, 240, 240, MangoLogo);
}

// TFT: show wifi
void drawWiFiState() {  
  char* _ssid = WiFi.SSID();
  tft.clr();  
  tft.fillScreen(ST7789_GREEN);
  tft.setBackground(ST7789_GREEN);
  tft.setForeground(ST7789_BLACK);
  tft.setFontSize(2);
  tft.setCursor(20, 20);    
  tft.println("WiFi:     ");
  tft.setCursor(20, 40);    
  tft.println(_ssid);
  tft.setCursor(20, 60);
  tft.println(ip);
}

// ------------ object detect ---------------------------------------------
void ObjectDetectPostProcess(std::vector<ObjectDetectionResult> results)
{
  uint16_t im_h = configCam.height();
  uint16_t im_w = configCam.width();

  printf("Total number of objects detected = %d\r\n", ObjDet.getResultCount());
  OSD.createBitmap(CHANNEL_IMG);
  if (ObjDet.getResultCount() > 0) {
    for (int i = 0; i < ObjDet.getResultCount(); i++) {
      int obj_type = results[i].type();
      if (itemList[obj_type].filter) {    // check if item should be ignored
        ObjectDetectionResult item = results[i];
        // Result coordinates are floats ranging from 0.00 to 1.00
        // Multiply with RTSP resolution to get coordinates in pixels
        int xmin = (int)(item.xMin() * im_w);
        int xmax = (int)(item.xMax() * im_w);
        int ymin = (int)(item.yMin() * im_h);
        int ymax = (int)(item.yMax() * im_h);
        // Draw boundary box
        printf("Item %d %s:\t%d %d %d %d\n\r", i, itemList[obj_type].objectName, xmin, xmax, ymin, ymax);
        OSD.drawRect(CHANNEL_IMG, xmin, ymin, xmax, ymax, 3, OSD_COLOR_WHITE);
        // Print identification text
        char text_str[20];
        snprintf(text_str, sizeof(text_str), "%s %d", itemList[obj_type].objectName, item.score());
        OSD.drawText(CHANNEL_IMG, xmin, ymin - OSD.getTextHeight(CHANNEL_IMG), text_str, OSD_COLOR_CYAN);
        // send to robot via uart
        char respText[20];
        snprintf(respText, sizeof(respText), "AI: %s %d", itemList[obj_type].objectName, item.score());
        Serial3.println(respText);
               
      }
    }
  }
  OSD.update(CHANNEL_IMG);
}
void startObjectDetect() {   
  // start object detect
  ObjDet.configVideo(configNN);
  ObjDet.setResultCallback(ObjectDetectPostProcess);
  ObjDet.modelSelect(OBJECT_DETECTION, DEFAULT_YOLOV7TINY, NA_MODEL, NA_MODEL); //CUSTOMIZED_YOLOV7TINY or DEFAULT_YOLOV7TINY
  ObjDet.begin();  
  // regist input stream
  videoStreamerNN.registerInput(Camera.getStream(CHANNEL_NN));
  videoStreamerNN.setStackSize();
  videoStreamerNN.setTaskPriority();
  videoStreamerNN.registerOutput(ObjDet);
  if (videoStreamerNN.begin() != 0) {
    Serial.println("StreamIO link start failed");
  }
  // Start OSD drawing on video channel
  OSD.configVideo(CHANNEL_IMG, configCam);
  OSD.begin();
}
void stopObjectDetect() {
  ObjDet.end();
  OSD.end();
  videoStreamerNN.end();
}

// ---------------- wifi connect ------------------------------------
void wifiConnect() {
  int wifiTryCount = 0;
  while (status != WL_CONNECTED) {
    Serial.print("Attempting to connect to WPA SSID: ");
    Serial.println(ssid);
    status = WiFi.begin(ssid, pass);
    // wait 2 seconds for connection:
    delay(2000);
    if(status == WL_CONNECTED) {
      drawWiFiState();
    }
    wifiTryCount++;
    if(wifiTryCount > wifiTryTimes) {
      Serial.println("No WiFi AP.");
      break;
    }
    Serial.print("WiFi try count: ");
    Serial.println(wifiTryCount);
  }
}

// begin: Serial handler --------------------------------------------
void cmdHandler(char inChar) {
  if (inChar == '0') {
    Serial.println("cmd: turn tft off");
    tft.setLightOn(false);
  }
  else if (inChar == '1') {
    Serial.println("cmd: turn tft on");
    tft.setLightOn(true);
    drawMangoLogo();
  }
  else if (inChar == '3') {
    Serial.println("cmd: begin object detect");
    startObjectDetect();
  }
  else if (inChar == '4') {
    Serial.println("cmd: end object detect");
    stopObjectDetect();
  }
}
// end: Serial handler --------------------------------------------

// begin: UART handler --------------------------------------------
bool stringComplete = false;
String cmd, task, data;

void uartHandler() {
  String uartRecvString = "";
  int incomingByte = 0;
  while(Serial3.available() > 0) {
    incomingByte  = Serial3.read();
    char inChar = (char)incomingByte; 
    if (inChar == '\n') {
      Serial3.println("Rv: " + uartRecvString);
      String cmd = split(uartRecvString, '|', 0);
      if(cmd == "WIFI") {
        String _ssid = split(uartRecvString, '|', 1);
        String _pswd = split(uartRecvString, '|', 2); 
        strcpy(ssid, _ssid.c_str());
        strcpy(pass, _pswd.c_str()); 
        wifiConnect();    
        Serial3.println("wifi restart...");    
      } 
      else if(cmd == "TEST") {
        String data1 = split(uartRecvString, '|', 1);
        String data2 = split(uartRecvString, '|', 2);
      }
      //uartRecvString = "";        
      break;
    }
    else {
      uartRecvString += inChar;
    }
  }
}
// end: UART handler --------------------------------------------


void setup()
{  
  pinMode(PIN_LED_BLUE, OUTPUT);
  digitalWrite(PIN_LED_BLUE, ledState);
  pinMode(PIN_LED_GREEN, OUTPUT);
  digitalWrite(PIN_LED_GREEN, ledState);
  pinMode(button, INPUT_IRQ_RISE);
  digitalSetIrqHandler(button, button_handler);  
  // SW3
  pinMode(PIN_SW3, INPUT_IRQ_RISE);
  digitalSetIrqHandler(PIN_SW3, sw3_handler);
  // Monitor
  Serial.begin(115200);  
  // TFT
  SPI1.setDefaultFrequency(ST7789_SPI_FREQUENCY);
  tft.begin(TFT_WIDTH, TFT_HEIGHT);
  tft.setLightOn(true);
  drawMangoLogo();
  delay(3000);
  
  // UART
  Serial3.begin(115200);
  while (!Serial3) yield();
  //Serial3.setCallback(uartHandler);
  if (xTaskCreate(TaskReadFromSerial, (const char *)"TaskReadFromSerial", 128, NULL, tskIDLE_PRIORITY+1, &xHandleSerialTask) != pdPASS)
  {
    Serial.println("Create UART Handler task failed");
  }

  // init. camera
  configCam.setBitrate(2 * 1024 * 1024); 
  Camera.configVideoChannel(CHANNEL_IMG, configCam);  
  Camera.configVideoChannel(CHANNEL_NN, configNN);
  Camera.videoInit();  
  Camera.channelBegin(CHANNEL_IMG); 
      
  // WiFi
  BLE.init();
  BLE.configServer(1);
  configService.addService();
  configService.begin();
  BLE.beginPeripheral();
  BLE.configAdvert()->stopAdv();
  BLE.configAdvert()->setAdvData(configService.advData());
  BLE.configAdvert()->updateAdvertParams();
  delay(100);
  BLE.configAdvert()->startAdv();
}

void loop()
{
  status = WiFi.status();
  if(!isServerStart && status == WL_CONNECTED) {
    // start server
    server.begin(); 
    isServerStart = true;
    // begin task    
    if (xTaskCreate(TaskHttpRequest, (const char *)"TaskHttpRequest", 2048, NULL, tskIDLE_PRIORITY+1, &xHandleHttpTask) != pdPASS)
    {
      Serial.println("Create httpRequest task failed");
    }
  }
  
  if(!gotIP)
  {    
    ip = WiFi.localIP();
  } 
  if(!gotIP && IPtoString(ip)!="0.0.0.0") {    
    drawWiFiState();
    Serial3.println(ip);
    gotIP = true;
  }  

  // server loss wifi connect
  if(isServerStart) {    
    status = WiFi.status();
    if(status != WL_CONNECTED) {
      isServerStart = false;
      gotIP = false;
      if( xHandleHttpTask != NULL )
      {
        startObjectDetect();
        vTaskDelete( xHandleHttpTask );
        drawMangoLogo();
      }      
    }
  }

  // Serial input
  if(Serial.available() > 0) {
    int inputValue  = Serial.read();    
    char inChar = (char)inputValue;    
    cmdHandler(inChar);
  }
  // UART
  //uartHandler();
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/
// begin: http request -------------------------------
void sendChunk(WiFiClient& client, uint8_t* buf, uint32_t len) {
  uint8_t chunk_buf[64] = {0};
  uint8_t chunk_len = snprintf((char*)chunk_buf, 64, "%lX\r\n", len);
  client.write(chunk_buf, chunk_len);
  client.write(buf, len);
  client.print("\r\n");
}
void TaskHttpRequest(void *param) {
  (void)param;
    
  while(isServerStart) 
  {
    WiFiClient client = server.available();
    if(client)
    {
      String currentLine = "";
      while(client.connected())
      {
        if(client.available())
        {
          char c = client.read();
          if(c == '\n')
          {
            if(currentLine.length() == 0)
            {
              client.println("HTTP/1.1 200 OK");
              client.print("Content-type: multipart/x-mixed-replace; boundary=");
              client.println(PART_BOUNDARY);
              client.print("Transfer-Encoding: chunked\r\n");
              client.print("\r\n");
              while (client.connected()) {
                Camera.getImage(CHANNEL_IMG, &img_addr, &img_len);
                uint8_t chunk_buf[64] = {0};
                uint8_t chunk_len = snprintf((char*)chunk_buf, 64, IMG_HEADER, img_len);
                sendChunk(client, chunk_buf, chunk_len);
                sendChunk(client, (uint8_t*)img_addr, img_len);
                sendChunk(client, (uint8_t*)STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));                           
                //delay(20);
                vTaskDelay( 20 );
              }
              break;
            } 
            else {
              currentLine = "";
            }
          } else if (c != '\r') {
            currentLine += c;
          }
        }
      }
      client.stop();
    }
  }      
}
// end: http request -------------------------------

// begin: read serial -------------------------------
void TaskReadFromSerial( void *pvParameters )
{
  (void) pvParameters;

  String uartRecvString = "";
  int incomingByte = 0;
  while (Serial3) {
    uartRecvString = "";
    while(Serial3.available() > 0) {
      incomingByte  = Serial3.read();
      char inChar = (char)incomingByte; 
      if (inChar == '\n') {
        Serial3.println("Rv: " + uartRecvString);
        String cmd = split(uartRecvString, '|', 0);
        if(cmd == "WIFI") {
          String _ssid = split(uartRecvString, '|', 1);
          String _pswd = split(uartRecvString, '|', 2); 
          strcpy(ssid, _ssid.c_str());
          strcpy(pass, _pswd.c_str()); 
          wifiConnect();    
          Serial3.println("wifi restart...");    
        } 
        else if(cmd == "TEST") {
          String data1 = split(uartRecvString, '|', 1);
          String data2 = split(uartRecvString, '|', 2);
        }
        //uartRecvString = "";        
        break;
      }
      else {
        uartRecvString += inChar;
      }
    }
    //uartRecvString = ""; 
    vTaskDelay(10000 / portTICK_PERIOD_MS);   
  }
  vTaskDelete( xHandleSerialTask ); 
}
// end: read serial ------------------------------